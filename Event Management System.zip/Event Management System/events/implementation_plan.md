# Database Repair Plan

## Goal
Fix `PDOException` errors by ensuring the database schema is correctly installed. The current state suggests missing tables or columns due to a failed previous setup (Foreign Key Order issues).

## Diagnosis
- **Error 1**: `Foreign key constraint is incorrectly formed` (from previous attempt).
- **Error 2**: `Unknown column 'e.professional_id'` (Event table exists but might be malformed or query is wrong).

## Proposed Solution
1. **Create `repair_db.php` script**:
    - Connect to MySQL.
    - Disable Foreign Key Checks (`SET FOREIGN_KEY_CHECKS = 0`).
    - **DROP** all existing tables (`bookings`, `events`, `reviews`, `messages`, `blocked_dates`, `professionals`, `users`, `categories`, `notifications`).
    - Re-enable Foreign Key Checks.
    - Re-run `database.sql` commands in correct dependency order.
    - Insert default data.

2. **Verify Database Structure**:
    - Ensure `users` and `professionals` are created *before* `events`.
    - Ensure `events` is created *before* `bookings`.
    - Ensure `professionals` is created *before* `blocked_dates`.

3. **Verify PHP Connection**:
    - Ensure `includes/db.php` is pointing to the correct DB (`eventhub`).

## Execution
- Run `C:\xampp\php\php.exe repair_db.php` to reset the database.
- Retry the application.
