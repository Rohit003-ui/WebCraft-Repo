<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';

// Get filters
$category_filter = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';

// Build query
$sql = "SELECT p.*, 
        (SELECT AVG(rating) FROM reviews WHERE professional_id = p.id) as avg_rating,
        (SELECT COUNT(*) FROM reviews WHERE professional_id = p.id) as review_count,
        (SELECT COUNT(*) FROM events WHERE professional_id = p.id) as event_count
        FROM professionals p WHERE 1=1";

$params = [];

if ($category_filter) {
    $sql .= " AND p.category = ?";
    $params[] = $category_filter;
}

if ($search) {
    $sql .= " AND (p.name LIKE ? OR p.location LIKE ? OR p.bio LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$sql .= " ORDER BY p.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$professionals = $stmt->fetchAll();

// Get categories for filter
$categories = $pdo->query("SELECT DISTINCT name FROM categories ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professionals', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-4">
    <?php include '../includes/breadcrumb.php'; ?>

    <!-- Back Button -->
    <a href="../index.php" class="btn btn-outline-secondary mb-3">
        <i class="fas fa-arrow-left me-2"></i>Back to Home
    </a>

    <h1 class="fw-bold mb-4">Browse Professionals</h1>

    <!-- Filters -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Search</label>
                    <input type="text" name="search" class="form-control" placeholder="Search by name, location..."
                        value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Category</label>
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat; ?>" <?php echo $category_filter == $cat ? 'selected' : ''; ?>>
                                <?php echo $cat; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2"><i class="fas fa-search me-2"></i>Search</button>
                    <a href="professionals.php" class="btn btn-outline-secondary">Clear</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Results -->
    <p class="text-muted mb-3">Found <?php echo count($professionals); ?> professional(s)</p>

    <?php if (count($professionals) > 0): ?>
        <div class="row g-4">
            <?php foreach ($professionals as $pro): ?>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100 hover-lift">
                        <div class="card-body">
                            <div class="text-center mb-3">
                                <img src="<?php echo getProfessionalImage($pro['profile_image'], $pro['name'], '../'); ?>"
                                    class="rounded-circle mb-3" width="120" height="120"
                                    alt="<?php echo htmlspecialchars($pro['name']); ?>">
                                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($pro['name']); ?></h5>
                                <span
                                    class="badge bg-primary bg-opacity-10 text-primary mb-2"><?php echo htmlspecialchars($pro['category']); ?></span>

                                <?php if ($pro['avg_rating']): ?>
                                    <div class="mb-2">
                                        <?php
                                        $rating = round($pro['avg_rating'], 1);
                                        for ($i = 1; $i <= 5; $i++):
                                            if ($i <= $rating): ?>
                                                <i class="fas fa-star text-warning"></i>
                                            <?php else: ?>
                                                <i class="far fa-star text-warning"></i>
                                            <?php endif;
                                        endfor; ?>
                                        <span class="ms-1"><?php echo $rating; ?> (<?php echo $pro['review_count']; ?>)</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <p class="text-muted small mb-2">
                                <i
                                    class="fas fa-map-marker-alt me-1"></i><?php echo $pro['location'] ?? 'Location not specified'; ?>
                            </p>
                            <p class="text-muted small mb-3"><?php echo substr(htmlspecialchars($pro['bio']), 0, 100); ?>...</p>
                            <p class="text-muted small mb-3">
                                <i class="fas fa-calendar-check me-1"></i><?php echo $pro['event_count']; ?> service(s) offered
                            </p>

                            <a href="professional_profile.php?id=<?php echo $pro['id']; ?>"
                                class="btn btn-primary-gradient w-100">
                                View Profile <i class="fas fa-arrow-right ms-2"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-users fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">No professionals found</h4>
            <p class="text-muted">Try adjusting your search filters</p>
            <a href="professionals.php" class="btn btn-primary">Clear Filters</a>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>