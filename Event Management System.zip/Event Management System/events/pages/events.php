<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
include '../includes/header.php';

$category_id = isset($_GET['category']) ? $_GET['category'] : '';
$search = isset($_GET['search']) ? cleanInput($_GET['search']) : '';
$date = isset($_GET['date']) ? $_GET['date'] : '';

$query = "SELECT e.*, p.name as professional_name, c.name as category_name 
          FROM events e 
          JOIN professionals p ON e.professional_id = p.id 
          JOIN categories c ON e.category_id = c.id 
          WHERE 1=1";
$params = [];

if ($category_id) {
    $query .= " AND e.category_id = ?";
    $params[] = $category_id;
}
if ($search) {
    $query .= " AND (e.title LIKE ? OR p.name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

// Note: Date filtering is complex because Events are generic packages.
// We can check if the professional is available on that date, but listing generic events usually just lists them.
// We will filter by listing available professionals?
// For simplicity, we just list the packages here. 
// If specific date is requested, maybe we highlight availability in details.

$query .= " ORDER BY e.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$events = $stmt->fetchAll();

// Fetch Categories for Filter
$stm_cat = $pdo->query("SELECT * FROM categories");
$cats = $stm_cat->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Events', 'url' => '']
];
?>

<div class="container py-4">
    <?php include '../includes/breadcrumb.php'; ?>

    <!-- Back Button -->
    <a href="../index.php" class="btn btn-outline-secondary mb-3">
        <i class="fas fa-arrow-left me-2"></i>Back to Home
    </a>

    <h1 class="fw-bold mb-4">Browse Events</h1>

    <div class="row">
        <!-- Filters -->
        <div class="col-lg-3 mb-4">
            <div class="card border-0 shadow-sm p-3">
                <h5 class="fw-bold mb-3">Filter Events</h5>
                <form method="GET">
                    <div class="mb-3">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" value="<?php echo $search; ?>"
                            placeholder="Event or Professional...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-select">
                            <option value="">All Categories</option>
                            <?php foreach ($cats as $c): ?>
                                <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $category_id ? 'selected' : ''; ?>><?php echo $c['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary-gradient w-100">Apply Filter</button>
                    <a href="events.php" class="btn btn-outline-secondary w-100 mt-2">Reset</a>
                </form>
            </div>
        </div>

        <!-- Event Grid -->
        <div class="col-lg-9">
            <div class="row g-4">
                <?php if (count($events) > 0): ?>
                    <?php foreach ($events as $event): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card event-card h-100">
                                <img src="<?php echo getEventImage($event['image'], $event['category_name'], '../'); ?>"
                                    class="event-img" alt="<?php echo htmlspecialchars($event['title']); ?>">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-2">
                                        <span
                                            class="badge bg-secondary bg-opacity-10 text-dark"><?php echo $event['category_name']; ?></span>
                                        <span class="fw-bold text-primary">₹<?php echo number_format($event['price']); ?></span>
                                    </div>
                                    <h5 class="card-title fw-bold"><?php echo htmlspecialchars($event['title']); ?></h5>
                                    <p class="text-muted small mb-2">by
                                        <?php echo htmlspecialchars($event['professional_name']); ?></p>
                                    <p class="small text-muted mb-3">
                                        <?php echo substr(htmlspecialchars($event['description']), 0, 80); ?>...</p>
                                    <a href="event_details.php?id=<?php echo $event['id']; ?>"
                                        class="btn btn-outline-primary w-100 rounded-pill">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 text-center py-5">
                        <h4 class="text-muted">No events found matching your criteria.</h4>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>