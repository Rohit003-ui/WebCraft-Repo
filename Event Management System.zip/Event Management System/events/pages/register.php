<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $role = $_POST['role']; // 'user' or 'professional'
    $name = cleanInput($_POST['name']);
    $email = cleanInput($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {
        if ($role == 'user') {
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $password]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO professionals (name, email, password, category) VALUES (?, ?, ?, 'General')");
            $stmt->execute([$name, $email, $password]);
        }
        $success = "Registration successful! You can now login.";
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $error = "Email already exists.";
        } else {
            $error = "Registration failed: " . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-5">
                    <h2 class="text-center fw-bold mb-4">Create Account</h2>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?> <a href="login.php">Login here</a></div>
                    <?php endif; ?>

                    <ul class="nav nav-pills mb-4 justify-content-center" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active rounded-pill px-4" id="pills-user-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-user" type="button" role="tab">I am a User</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill px-4" id="pills-pro-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-pro" type="button" role="tab">I am a Professional</button>
                        </li>
                    </ul>

                    <div class="tab-content" id="pills-tabContent">
                        <!-- User Form -->
                        <div class="tab-pane fade show active" id="pills-user" role="tabpanel">
                            <form method="POST">
                                <input type="hidden" name="role" value="user">
                                <div class="mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary-gradient w-100 mt-3">Register as
                                    User</button>
                            </form>
                        </div>

                        <!-- Professional Form -->
                        <div class="tab-pane fade" id="pills-pro" role="tabpanel">
                            <form method="POST">
                                <input type="hidden" name="role" value="professional">
                                <div class="mb-3">
                                    <label class="form-label">Business / Professional Name</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <div class="form-text mb-3">You can complete your profile (Bio, Category, Pricing) after
                                    login.</div>
                                <button type="submit" class="btn btn-primary-gradient w-100 mt-3">Register as
                                    Professional</button>
                            </form>
                        </div>
                    </div>

                    <div class="text-center mt-4">
                        <p>Already have an account? <a href="login.php" class="text-primary fw-bold">Login</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>