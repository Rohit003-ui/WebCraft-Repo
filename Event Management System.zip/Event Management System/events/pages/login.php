<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $role = $_POST['role'];
    $email = cleanInput($_POST['email']);
    $password = $_POST['password'];

    if ($role == 'user') {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            redirect('../user/dashboard.php');
        } else {
            $error = "Invalid User credentials.";
        }
    } else {
        $stmt = $pdo->prepare("SELECT * FROM professionals WHERE email = ?");
        $stmt->execute([$email]);
        $pro = $stmt->fetch();

        if ($pro && password_verify($password, $pro['password'])) {
            $_SESSION['professional_id'] = $pro['id'];
            $_SESSION['professional_name'] = $pro['name'];
            redirect('../professional/dashboard.php');
        } else {
            $error = "Invalid Professional credentials.";
        }
    }
}

include '../includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-5">
                    <h2 class="text-center fw-bold mb-4">Welcome Back</h2>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>

                    <ul class="nav nav-pills mb-4 justify-content-center" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active rounded-pill px-4" id="pills-user-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-user" type="button" role="tab">User Login</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link rounded-pill px-4" id="pills-pro-tab" data-bs-toggle="pill"
                                data-bs-target="#pills-pro" type="button" role="tab">Professional Login</button>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <!-- User Login -->
                        <div class="tab-pane fade show active" id="pills-user">
                            <form method="POST">
                                <input type="hidden" name="role" value="user">
                                <div class="mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary-gradient w-100 mt-3">Login as User</button>
                            </form>
                        </div>

                        <!-- Professional Login -->
                        <div class="tab-pane fade" id="pills-pro">
                            <form method="POST">
                                <input type="hidden" name="role" value="professional">
                                <div class="mb-3">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary-gradient w-100 mt-3">Login as
                                    Professional</button>
                            </form>
                        </div>
                    </div>

                    <div class="text-center mt-4">
                        <p>Don't have an account? <a href="register.php" class="text-primary fw-bold">Sign Up</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>