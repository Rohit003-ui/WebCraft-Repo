<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';

if (!isset($_GET['id']))
    redirect('events.php');
$event_id = $_GET['id'];

$stmt = $pdo->prepare("SELECT e.*, p.name as professional_name, p.bio, p.location, p.profile_image, c.name as category_name 
                       FROM events e 
                       JOIN professionals p ON e.professional_id = p.id 
                       JOIN categories c ON e.category_id = c.id 
                       WHERE e.id = ?");
$stmt->execute([$event_id]);
$event = $stmt->fetch();

if (!$event)
    redirect('events.php');

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $date = $_POST['date'];
    $time = $_POST['time'];
    $guest_count = $_POST['guest_count'] ?? 1;
    $venue = cleanInput($_POST['venue'] ?? '');
    $requirements = cleanInput($_POST['requirements'] ?? '');
    $user_id = $_SESSION['user_id'];
    $pro_id = $event['professional_id'];

    // Calculate payment
    $event_price = $event['price'];
    $platform_fee = $event_price * 0.10; // 10% commission
    $total_amount = $event_price + $platform_fee;
    $professional_amount = $event_price;

    // Check Availability
    $chk = $pdo->prepare("SELECT COUNT(*) FROM blocked_dates WHERE professional_id = ? AND blocked_date = ?");
    $chk->execute([$pro_id, $date]);
    if ($chk->fetchColumn() > 0) {
        $error = "This date is blocked by the professional.";
    } else {
        $chk2 = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE professional_id = ? AND booking_date = ? AND status = 'confirmed'");
        $chk2->execute([$pro_id, $date]);
        if ($chk2->fetchColumn() > 0) {
            $error = "The professional is already booked on this date.";
        } else {
            // Book with enhanced details
            $ins = $pdo->prepare("INSERT INTO bookings (user_id, professional_id, event_id, booking_date, booking_time, guest_count, venue_address, special_requirements, total_amount, platform_fee, professional_amount, payment_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
            if ($ins->execute([$user_id, $pro_id, $event_id, $date, $time, $guest_count, $venue, $requirements, $total_amount, $platform_fee, $professional_amount])) {
                $success = "Booking request sent successfully! Total Amount: ₹" . number_format($total_amount) . " (includes ₹" . number_format($platform_fee) . " platform fee). Wait for professional confirmation.";
            } else {
                $error = "Something went wrong.";
            }
        }
    }
}

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Events', 'url' => 'events.php'],
    ['name' => $event['title'], 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-4">
    <?php include '../includes/breadcrumb.php'; ?>

    <!-- Back Button -->
    <a href="events.php" class="btn btn-outline-secondary mb-3">
        <i class="fas fa-arrow-left me-2"></i>Back to Events
    </a>

    <div class="row">
        <!-- Image & Pro Info -->
        <div class="col-md-5 mb-4">
            <img src="<?php echo getEventImage($event['image'], $event['category_name'], '../'); ?>"
                class="img-fluid rounded-4 shadow mb-4" alt="<?php echo htmlspecialchars($event['title']); ?>">

            <div class="card border-0 shadow-sm p-3">
                <div class="d-flex align-items-center mb-3">
                    <img src="<?php echo getProfessionalImage($event['profile_image'], $event['professional_name'], '../'); ?>"
                        class="rounded-circle me-3" width="60" height="60"
                        alt="<?php echo htmlspecialchars($event['professional_name']); ?>">
                    <div>
                        <h6 class="fw-bold mb-0">Hosted by <?php echo htmlspecialchars($event['professional_name']); ?>
                        </h6>
                        <small class="text-muted"><i class="fas fa-map-marker-alt"></i>
                            <?php echo htmlspecialchars($event['location'] ?? 'Remote/On-site'); ?></small>
                    </div>
                </div>
                <p class="text-muted small mb-0"><?php echo htmlspecialchars($event['bio']); ?></p>
            </div>
        </div>

        <!-- Details & Booking -->
        <div class="col-md-7">
            <span class="badge bg-primary bg-opacity-10 text-primary mb-2"><?php echo $event['category_name']; ?></span>
            <h1 class="fw-bold mb-3"><?php echo $event['title']; ?></h1>
            <h3 class="text-primary fw-bold mb-4">₹<?php echo number_format($event['price']); ?> <span
                    class="fs-6 text-muted fw-normal">/ session</span></h3>

            <h5 class="fw-bold">Description</h5>
            <p class="text-muted mb-5"><?php echo nl2br($event['description']); ?></p>

            <div class="card bg-light border-0 p-4 rounded-4">
                <h4 class="fw-bold mb-3">Book This Event</h4>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <form method="POST">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Select Date *</label>
                                <input type="date" name="date" class="form-control" required
                                    min="<?php echo date('Y-m-d'); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Select Time *</label>
                                <input type="time" name="time" class="form-control" required>
                                <small class="text-muted">Use AM/PM in your browser's time picker</small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Number of Guests *</label>
                                <input type="number" name="guest_count" class="form-control" value="1" min="1" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Venue/Location *</label>
                                <input type="text" name="venue" class="form-control" placeholder="Event venue address"
                                    required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Special Requirements (Optional)</label>
                                <textarea name="requirements" class="form-control" rows="3"
                                    placeholder="Any special requests or requirements..."></textarea>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-info mb-3">
                                    <strong>Payment Summary:</strong><br>
                                    Event Price: ₹<?php echo number_format($event['price']); ?><br>
                                    Platform Fee (10%): ₹<?php echo number_format($event['price'] * 0.10); ?><br>
                                    <strong>Total Amount: ₹<?php echo number_format($event['price'] * 1.10); ?></strong>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary-gradient w-100 py-2">Request Booking</button>
                                <small class="text-muted d-block mt-2">Payment will be processed after professional confirms
                                    your booking.</small>
                            </div>
                        </div>
                    </form>
                <?php elseif (isset($_SESSION['professional_id'])): ?>
                    <div class="alert alert-info">Professional accounts cannot request bookings.</div>
                <?php else: ?>
                    <div class="text-center">
                        <p class="text-muted mb-3">Please login to book this event.</p>
                        <a href="login.php" class="btn btn-primary-gradient px-5">Login Now</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>