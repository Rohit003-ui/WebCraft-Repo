<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';

if (!isset($_GET['id'])) {
    redirect('professionals.php');
}

$pro_id = $_GET['id'];

// Get professional details
$stmt = $pdo->prepare("SELECT p.*, 
    (SELECT AVG(rating) FROM reviews WHERE professional_id = p.id) as avg_rating,
    (SELECT COUNT(*) FROM reviews WHERE professional_id = p.id) as review_count
    FROM professionals p WHERE p.id = ?");
$stmt->execute([$pro_id]);
$professional = $stmt->fetch();

if (!$professional) {
    redirect('professionals.php');
}

// Get professional's events
$stmt = $pdo->prepare("SELECT e.*, c.name as category_name FROM events e 
    JOIN categories c ON e.category_id = c.id 
    WHERE e.professional_id = ? ORDER BY e.created_at DESC");
$stmt->execute([$pro_id]);
$events = $stmt->fetchAll();

// Get reviews
$stmt = $pdo->prepare("SELECT r.*, u.name as user_name, b.booking_date 
    FROM reviews r 
    JOIN users u ON r.user_id = u.id 
    JOIN bookings b ON r.booking_id = b.id
    WHERE r.professional_id = ? 
    ORDER BY r.created_at DESC LIMIT 10");
$stmt->execute([$pro_id]);
$reviews = $stmt->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professionals', 'url' => 'professionals.php'],
    ['name' => $professional['name'], 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-4">
    <?php include '../includes/breadcrumb.php'; ?>

    <!-- Back Button -->
    <a href="professionals.php" class="btn btn-outline-secondary mb-4">
        <i class="fas fa-arrow-left me-2"></i>Back to Professionals
    </a>

    <div class="row">
        <!-- Professional Info -->
        <div class="col-md-4 mb-4">
            <div class="card border-0 shadow-sm sticky-top" style="top: 100px;">
                <div class="card-body text-center">
                    <img src="<?php echo getProfessionalImage($professional['profile_image'], $professional['name'], '../'); ?>"
                        class="rounded-circle mb-3" width="150" height="150"
                        alt="<?php echo htmlspecialchars($professional['name']); ?>">

                    <h3 class="fw-bold mb-2"><?php echo htmlspecialchars($professional['name']); ?></h3>
                    <span
                        class="badge bg-primary bg-opacity-10 text-primary mb-3"><?php echo $professional['category']; ?></span>

                    <?php if ($professional['avg_rating']): ?>
                        <div class="mb-3">
                            <?php
                            $rating = round($professional['avg_rating'], 1);
                            for ($i = 1; $i <= 5; $i++):
                                if ($i <= $rating): ?>
                                    <i class="fas fa-star text-warning"></i>
                                <?php else: ?>
                                    <i class="far fa-star text-warning"></i>
                                <?php endif;
                            endfor; ?>
                            <div class="mt-2">
                                <strong><?php echo $rating; ?></strong> / 5.0
                                <div class="text-muted small"><?php echo $professional['review_count']; ?> review(s)</div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <hr>

                    <div class="text-start">
                        <p class="mb-2"><i
                                class="fas fa-map-marker-alt text-primary me-2"></i><?php echo $professional['location'] ?? 'Not specified'; ?>
                        </p>
                        <p class="mb-2"><i
                                class="fas fa-calendar-check text-primary me-2"></i><?php echo count($events); ?>
                            service(s)</p>
                        <p class="mb-0"><i
                                class="fas fa-star text-primary me-2"></i><?php echo $professional['review_count']; ?>
                            review(s)</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-8">
            <!-- About -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <h4 class="fw-bold mb-3">About</h4>
                    <p class="text-muted"><?php echo nl2br(htmlspecialchars($professional['bio'])); ?></p>
                </div>
            </div>

            <!-- Services/Events -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <h4 class="fw-bold mb-3">Services Offered (<?php echo count($events); ?>)</h4>

                    <?php if (count($events) > 0): ?>
                        <div class="row g-3">
                            <?php foreach ($events as $event): ?>
                                <div class="col-md-6">
                                    <div class="card border h-100">
                                        <div class="card-body">
                                            <h6 class="fw-bold mb-2"><?php echo htmlspecialchars($event['title']); ?></h6>
                                            <span
                                                class="badge bg-info bg-opacity-10 text-info mb-2"><?php echo $event['category_name']; ?></span>
                                            <p class="text-muted small mb-2">
                                                <?php echo substr(htmlspecialchars($event['description']), 0, 80); ?>...
                                            </p>
                                            <p class="text-primary fw-bold mb-2">₹<?php echo number_format($event['price']); ?>
                                            </p>
                                            <a href="event_details.php?id=<?php echo $event['id']; ?>"
                                                class="btn btn-sm btn-outline-primary w-100">
                                                View Details <i class="fas fa-arrow-right ms-1"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No services listed yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Reviews -->
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h4 class="fw-bold mb-3">Reviews (<?php echo count($reviews); ?>)</h4>

                    <?php if (count($reviews) > 0): ?>
                        <?php foreach ($reviews as $review): ?>
                            <div class="border-bottom pb-3 mb-3">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <strong><?php echo htmlspecialchars($review['user_name']); ?></strong>
                                        <div class="small text-muted">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <?php if ($i <= $review['rating']): ?>
                                                    <i class="fas fa-star text-warning"></i>
                                                <?php else: ?>
                                                    <i class="far fa-star text-warning"></i>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    <small
                                        class="text-muted"><?php echo date('d M Y', strtotime($review['created_at'])); ?></small>
                                </div>
                                <p class="text-muted mb-0"><?php echo htmlspecialchars($review['comment']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-muted">No reviews yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>