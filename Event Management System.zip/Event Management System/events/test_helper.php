<?php
require 'includes/image_helpers.php';
$url = 'https://images.unsplash.com/photo-1519741497674-611481863552?w=400';
echo "Test 1: " . getProfessionalImage($url, "Test") . "\n";
$file = 'test.jpg';
echo "Test 2: " . getProfessionalImage($file, "Test") . "\n";
?>