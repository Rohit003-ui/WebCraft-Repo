# EventHub - Event Management System

## Setup Instructions

1. **Server Requirements**:
   - Install **XAMPP** (or WAMP/MAMP).
   - Start **Apache** and **MySQL**.

2. **Database Setup**:
   - Open phpMyAdmin (`http://localhost/phpmyadmin`).
   - Create a new database named `eventhub`.
   - Import the `database.sql` file located in this project folder.
   
   *Alternatively, if running the SQL script manually, ensure the database name matches `includes/db.php`.*

3. **Project Location**:
   - Move or Copy this entire folder to your server's root directory (e.g., `C:\xampp\htdocs\EventHub`).
   - Or, serve this directory using PHP's built-in server (for testing only):
     ```bash
     php -S localhost:8000
     ```

4. **Accessing the App**:
   - Open browser and go to: `http://localhost/EventHub` (or `http://localhost:8000` if using built-in server).

## Features

- **Users**: Register, Search Events, Book Events, Chat with Professionals, Leave Reviews.
- **Professionals**: Create Profile, CRUD Events, Manage Bookings, Block Calendar Dates, Chat with Users.
- **Admin**: Not explicitly requested but Database is structured for it.

## Default Credentials
- Register a new User or Professional to start.

## Folder Structure
- `/assets`: CSS, JS, Images, Uploads.
- `/includes`: DB connection, Header, Footer.
- `/pages`: Public pages (Login, Register, Events).
- `/professional`: Professional Dashboard & Tools.
- `/user`: User Dashboard & Tools.
- `/api`: AJAX handlers and Logic actions.
