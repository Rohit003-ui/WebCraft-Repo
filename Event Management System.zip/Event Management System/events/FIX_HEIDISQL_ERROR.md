# Fix for HeidiSQL "registrations" Table Error

## Problem
HeidiSQL is showing error: `Table 'eventhub.registrations' doesn't exist`

## Why This Happens
- The `registrations` table was never created (it's not needed)
- HeidiSQL might be caching old table references
- Or you clicked on a table that doesn't exist

## ✅ Solution

### Step 1: Refresh HeidiSQL
1. In HeidiSQL, click on the **database name** (`eventhub`)
2. Press **F5** to refresh
3. Or right-click → **Refresh**

### Step 2: Close Error Dialog
1. Click **OK** on the error dialog
2. Don't click on "registrations" table (if it appears in the list)

### Step 3: Verify Tables
You should see these tables in HeidiSQL:
- ✅ users
- ✅ professionals
- ✅ categories
- ✅ events
- ✅ bookings
- ✅ blocked_dates
- ✅ messages
- ✅ reviews
- ✅ notifications
- ✅ transactions

### Step 4: If Error Persists
1. Close HeidiSQL completely
2. Reopen HeidiSQL
3. Reconnect to the database
4. Refresh the database

## 🎯 What You Can Do Now

### View Users Table
1. Click on **users** table in HeidiSQL
2. Click **Data** tab
3. You'll see all user accounts
4. Password column shows encrypted hashes (this is normal)

### View Professionals Table
1. Click on **professionals** table
2. Click **Data** tab
3. You'll see all professional accounts
4. Password column shows encrypted hashes

### View Bookings Table
1. Click on **bookings** table
2. Click **Data** tab
3. You'll see all booking details including:
   - guest_count
   - venue_address
   - special_requirements
   - total_amount
   - platform_fee
   - payment_status

## 📝 Important Notes

1. **Passwords are encrypted** - You cannot see plain text passwords in the database
2. **Use credentials page** - Open `http://localhost/for/view_credentials.php` to see login credentials
3. **All passwords are**: `password123`

## 🔧 Alternative: Use phpMyAdmin

If HeidiSQL continues to have issues:
1. Open browser
2. Go to: `http://localhost/phpmyadmin`
3. Click on `eventhub` database
4. Browse tables there

## ✅ Quick Test

To verify everything works:
1. Close the error dialog in HeidiSQL
2. Click on **professionals** table
3. Click **Data** tab
4. You should see 10-11 professionals
5. Check the **email** column - you'll see `royal@eventhub.com`, etc.
6. Check the **password** column - you'll see encrypted hashes like `$2y$10$...`

**This is correct!** Use `password123` to login, not the hash.
