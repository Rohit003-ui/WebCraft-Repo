<?php
$host = 'localhost';
$dbname = 'eventhub';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    // Check tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);

    echo "Tables found: " . implode(", ", $tables) . "\n";

    if (count($tables) >= 9) {
        echo "SUCCESS: Database seems healthy.\n";
    } else {
        echo "FAILURE: Missing tables.\n";
    }

} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage();
}
?>