<?php
require 'includes/db.php';

echo "Adding events to existing professionals...\n\n";

// Get all professionals
$stmt = $pdo->query("SELECT id, email, category FROM professionals WHERE email LIKE '%@eventhub.com' ORDER BY id");
$professionals = $stmt->fetchAll();

if (count($professionals) == 0) {
    die("No professionals found. Run seed_data.php first.\n");
}

// Map professionals by category
$pro_map = [];
foreach ($professionals as $pro) {
    if (!isset($pro_map[$pro['category']])) {
        $pro_map[$pro['category']] = [];
    }
    $pro_map[$pro['category']][] = $pro['id'];
}

// Get category IDs
$categories = $pdo->query("SELECT name, id FROM categories")->fetchAll(PDO::FETCH_KEY_PAIR);

// Sample events
$events = [
    // Function events
    ['category' => 'Function', 'title' => 'Complete Wedding Planning Package', 'desc' => 'Full-service wedding planning including venue, catering, decoration, photography, and coordination. Perfect for grand weddings.', 'price' => 150000],
    ['category' => 'Function', 'title' => 'Destination Wedding Package', 'desc' => 'Exotic destination wedding planning with travel arrangements, accommodation, and complete event management.', 'price' => 300000],
    ['category' => 'Function', 'title' => 'Engagement Ceremony Planning', 'desc' => 'Beautiful engagement ceremony setup with decoration, catering, and entertainment arrangements.', 'price' => 50000],
    ['category' => 'Function', 'title' => 'Traditional Wedding Package', 'desc' => 'Traditional wedding planning with cultural rituals, mandap decoration, and authentic catering.', 'price' => 120000],
    ['category' => 'Function', 'title' => 'Reception Party Planning', 'desc' => 'Grand reception party with DJ, lighting, catering, and complete venue management.', 'price' => 80000],

    // Party events
    ['category' => 'Party', 'title' => 'Birthday Party Package', 'desc' => 'Complete birthday party setup with theme decoration, games, entertainment, and catering for 50 guests.', 'price' => 25000],
    ['category' => 'Party', 'title' => 'Corporate Party Planning', 'desc' => 'Professional corporate party organization with team activities, catering, and entertainment.', 'price' => 75000],
    ['category' => 'Party', 'title' => 'Theme Party Package', 'desc' => 'Customized theme party with decoration, costumes, props, and entertainment based on your choice.', 'price' => 40000],
    ['category' => 'Party', 'title' => 'Kids Birthday Bash', 'desc' => 'Fun-filled kids birthday party with games, magic show, balloon decoration, and cake.', 'price' => 15000],
    ['category' => 'Party', 'title' => 'Anniversary Celebration', 'desc' => 'Romantic anniversary celebration setup with decoration, candlelight dinner, and photography.', 'price' => 30000],

    // Concert events
    ['category' => 'Concert', 'title' => 'Live Concert Production', 'desc' => 'Complete concert production with sound system, stage setup, lighting, and artist coordination.', 'price' => 200000],
    ['category' => 'Concert', 'title' => 'Music Festival Management', 'desc' => 'Multi-day music festival organization with multiple stages, artist management, and logistics.', 'price' => 500000],
    ['category' => 'Concert', 'title' => 'College Fest Concert', 'desc' => 'College festival concert with popular artists, sound system, and stage management.', 'price' => 150000],
    ['category' => 'Concert', 'title' => 'Corporate Event Concert', 'desc' => 'Professional concert setup for corporate events with premium sound and lighting.', 'price' => 180000],
    ['category' => 'Concert', 'title' => 'Acoustic Night Setup', 'desc' => 'Intimate acoustic performance setup with quality sound system and ambient lighting.', 'price' => 50000],

    // Seminar events
    ['category' => 'Seminar', 'title' => 'Corporate Training Seminar', 'desc' => 'Professional training seminar with expert speakers, venue, and training materials for 100 participants.', 'price' => 60000],
    ['category' => 'Seminar', 'title' => 'Leadership Workshop', 'desc' => 'Interactive leadership development workshop with activities, case studies, and certification.', 'price' => 45000],
    ['category' => 'Seminar', 'title' => 'Technical Skill Seminar', 'desc' => 'Hands-on technical training seminar with lab setup, expert trainers, and course materials.', 'price' => 55000],
    ['category' => 'Seminar', 'title' => 'Academic Conference', 'desc' => 'Multi-day academic conference with keynote speakers, paper presentations, and networking sessions.', 'price' => 100000],
    ['category' => 'Seminar', 'title' => 'Student Career Seminar', 'desc' => 'Career guidance seminar for students with industry experts, resume workshops, and mock interviews.', 'price' => 30000],

    // Workspace events
    ['category' => 'Workspace', 'title' => 'Monthly Coworking Desk', 'desc' => 'Dedicated desk in premium coworking space with high-speed internet, meeting rooms, and amenities.', 'price' => 8000],
    ['category' => 'Workspace', 'title' => 'Private Office Space', 'desc' => 'Fully furnished private office for 5-10 people with 24/7 access and all facilities.', 'price' => 50000],
    ['category' => 'Workspace', 'title' => 'Meeting Room Rental', 'desc' => 'Professional meeting room rental with projector, whiteboard, and refreshments for 20 people.', 'price' => 5000],

    // Conference events
    ['category' => 'Conference', 'title' => 'International Tech Summit', 'desc' => 'Large-scale tech conference with international speakers, exhibition area, and networking events.', 'price' => 800000],
    ['category' => 'Conference', 'title' => 'Business Conference', 'desc' => 'Professional business conference with panel discussions, workshops, and networking opportunities.', 'price' => 250000],
    ['category' => 'Conference', 'title' => 'Medical Conference', 'desc' => 'Medical professionals conference with CME credits, expert sessions, and exhibition.', 'price' => 350000]
];

// Insert events
$event_count = 0;
foreach ($events as $event) {
    $category = $event['category'];

    if (!isset($pro_map[$category]) || count($pro_map[$category]) == 0) {
        echo "⚠ No professional found for category: $category\n";
        continue;
    }

    // Distribute events among professionals in this category
    $pro_id = $pro_map[$category][$event_count % count($pro_map[$category])];
    $cat_id = $categories[$category];

    try {
        $stmt = $pdo->prepare("INSERT INTO events (professional_id, title, description, category_id, price) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$pro_id, $event['title'], $event['desc'], $cat_id, $event['price']]);
        echo "✓ Created: {$event['title']}\n";
        $event_count++;
    } catch (PDOException $e) {
        echo "✗ Failed: {$event['title']} - " . $e->getMessage() . "\n";
    }
}

echo "\n✅ Added $event_count events!\n";
echo "\nSample Professional Logins:\n";
echo "Email: royal@eventhub.com | Password: password123\n";
echo "Email: party@eventhub.com | Password: password123\n";
echo "Email: livemusic@eventhub.com | Password: password123\n";
?>