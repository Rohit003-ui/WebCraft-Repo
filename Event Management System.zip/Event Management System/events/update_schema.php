<?php
require 'includes/db.php';

echo "Updating database schema...\n\n";

try {
    // Add new columns to bookings table
    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS guest_count INT DEFAULT 1");
    echo "✓ Added guest_count column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS venue_address TEXT");
    echo "✓ Added venue_address column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS special_requirements TEXT");
    echo "✓ Added special_requirements column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS total_amount DECIMAL(10,2)");
    echo "✓ Added total_amount column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS platform_fee DECIMAL(10,2)");
    echo "✓ Added platform_fee column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS professional_amount DECIMAL(10,2)");
    echo "✓ Added professional_amount column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending'");
    echo "✓ Added payment_status column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_id VARCHAR(255)");
    echo "✓ Added payment_id column\n";

    $pdo->exec("ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50)");
    echo "✓ Added payment_method column\n";

    // Create transactions table
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        booking_id INT NOT NULL,
        amount DECIMAL(10,2),
        platform_fee DECIMAL(10,2),
        professional_amount DECIMAL(10,2),
        payment_gateway VARCHAR(50),
        transaction_id VARCHAR(255),
        status ENUM('success', 'failed', 'refunded') DEFAULT 'success',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
    )");
    echo "✓ Created transactions table\n";

    echo "\n✅ DATABASE SCHEMA UPDATE COMPLETE!\n";

} catch (PDOException $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
}
?>