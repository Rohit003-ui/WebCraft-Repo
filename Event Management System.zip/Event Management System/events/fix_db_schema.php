<?php
require 'includes/db.php';

echo "Fixing database schema issues...\n\n";

try {
    // Drop the registrations table if it exists (it shouldn't, but just in case)
    $pdo->exec("DROP TABLE IF EXISTS registrations");
    echo "✓ Cleaned up registrations table\n";

    // Verify all required tables exist
    $required_tables = [
        'users',
        'professionals',
        'categories',
        'events',
        'bookings',
        'blocked_dates',
        'messages',
        'reviews',
        'notifications',
        'transactions'
    ];

    echo "\nVerifying tables:\n";
    foreach ($required_tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            echo "✓ $table exists\n";
        } else {
            echo "✗ $table MISSING\n";
        }
    }

    echo "\n✅ Database schema check complete!\n";
    echo "\nYou can now use HeidiSQL without errors.\n";
    echo "The 'registrations' table error should be gone.\n";

} catch (PDOException $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
}
?>