<?php
require 'includes/db.php';

echo "Resetting all passwords to 'password123'...\n\n";

$new_password = password_hash('password123', PASSWORD_DEFAULT);

// Reset professional passwords
$stmt = $pdo->prepare("UPDATE professionals SET password = ?");
$stmt->execute([$new_password]);
$pro_count = $stmt->rowCount();
echo "✓ Reset $pro_count professional passwords\n";

// Reset user passwords
$stmt = $pdo->prepare("UPDATE users SET password = ?");
$stmt->execute([$new_password]);
$user_count = $stmt->rowCount();
echo "✓ Reset $user_count user passwords\n";

echo "\n✅ All passwords reset to: password123\n";
echo "\nYou can now login with:\n";
echo "- Professional: royal@eventhub.com / password123\n";
echo "- Professional: party@eventhub.com / password123\n";
echo "- Any user account / password123\n";
?>