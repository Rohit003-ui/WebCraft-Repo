# EventHub - Test Account Credentials

## 🔐 Professional Accounts

All professional accounts use password: **password123**

| Email | Password | Category | Name |
|-------|----------|----------|------|
| royal@eventhub.com | password123 | Function | Royal Wedding Planners |
| dream@eventhub.com | password123 | Function | Dream Events Co. |
| party@eventhub.com | password123 | Party | Party Masters |
| celebration@eventhub.com | password123 | Party | Celebration Hub |
| livemusic@eventhub.com | password123 | Concert | Live Music Productions |
| soundstage@eventhub.com | password123 | Concert | Sound & Stage |
| knowledge@eventhub.com | password123 | Seminar | Knowledge Hub |
| eduevents@eventhub.com | password123 | Seminar | Edu Events |
| cowork@eventhub.com | password123 | Workspace | CoWork Spaces |
| global@eventhub.com | password123 | Conference | Global Conference Organizers |

## 👤 User Accounts

Create your own user account or use:
- Any email you register with
- Password: whatever you set during registration

## 🔧 If Login Fails

Run this command to reset ALL passwords to "password123":
```bash
C:\xampp\php\php.exe reset_passwords.php
```

## 📝 Notes

- Passwords are encrypted using PHP's `password_hash()` for security
- You cannot see encrypted passwords in the database (this is intentional)
- Use this file as your reference for login credentials
- For production, change all passwords to strong, unique values

## 🎯 Quick Login Test

**Professional Login:**
1. Go to: http://localhost/for/pages/login.php
2. Click "Professional Login" tab
3. Email: `royal@eventhub.com`
4. Password: `password123`
5. Click "Login as Professional"

**User Login:**
1. Go to: http://localhost/for/pages/login.php
2. Click "User Login" tab
3. Use your registered email
4. Use your password
