<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];

$stmt = $pdo->prepare("
    SELECT b.*, u.name as user_name, u.email as user_email, u.phone as user_phone, e.title as event_title 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN events e ON b.event_id = e.id
    WHERE b.professional_id = ?
    ORDER BY b.created_at DESC
");
$stmt->execute([$pro_id]);
$bookings = $stmt->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'All Bookings', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <h2 class="fw-bold mb-4">All Booking Requests</h2>
    
    <?php if(count($bookings) > 0): ?>
        <div class="row g-4">
            <?php foreach($bookings as $booking): ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h5 class="fw-bold mb-1"><?php echo $booking['event_title']; ?></h5>
                                        <p class="text-muted mb-0">
                                            <i class="fas fa-user me-2"></i><?php echo $booking['user_name']; ?>
                                            <span class="ms-3"><i class="fas fa-envelope me-2"></i><?php echo $booking['user_email']; ?></span>
                                            <?php if($booking['user_phone']): ?>
                                                <span class="ms-3"><i class="fas fa-phone me-2"></i><?php echo $booking['user_phone']; ?></span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <?php 
                                    $badge = 'bg-secondary';
                                    if($booking['status'] == 'confirmed') $badge = 'bg-success';
                                    if($booking['status'] == 'pending') $badge = 'bg-warning text-dark';
                                    if($booking['status'] == 'cancelled') $badge = 'bg-danger';
                                    if($booking['status'] == 'completed') $badge = 'bg-info';
                                    ?>
                                    <span class="badge <?php echo $badge; ?> rounded-pill"><?php echo ucfirst($booking['status']); ?></span>
                                </div>
                                
                                <div class="row g-3 mb-3">
                                    <div class="col-md-4">
                                        <small class="text-muted d-block">Event Date & Time</small>
                                        <strong><i class="fas fa-calendar me-2"></i><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></strong><br>
                                        <strong><i class="fas fa-clock me-2"></i><?php echo date('h:i A', strtotime($booking['booking_time'])); ?></strong>
                                    </div>
                                    <div class="col-md-4">
                                        <small class="text-muted d-block">Guests</small>
                                        <strong><i class="fas fa-users me-2"></i><?php echo $booking['guest_count'] ?? 'Not specified'; ?> people</strong>
                                    </div>
                                    <div class="col-md-4">
                                        <small class="text-muted d-block">Payment</small>
                                        <strong class="text-success"><i class="fas fa-rupee-sign me-2"></i><?php echo number_format($booking['total_amount'] ?? 0); ?></strong>
                                        <small class="d-block text-muted">You receive: ₹<?php echo number_format($booking['professional_amount'] ?? 0); ?></small>
                                    </div>
                                </div>
                                
                                <?php if($booking['venue_address']): ?>
                                <div class="mb-2">
                                    <small class="text-muted d-block">Venue</small>
                                    <p class="mb-0"><i class="fas fa-map-marker-alt me-2"></i><?php echo $booking['venue_address']; ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if($booking['special_requirements']): ?>
                                <div class="mb-2">
                                    <small class="text-muted d-block">Special Requirements</small>
                                    <p class="mb-0 text-muted"><?php echo nl2br($booking['special_requirements']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <small class="text-muted">Requested on: <?php echo date('d M Y, h:i A', strtotime($booking['created_at'])); ?></small>
                            </div>
                            
                            <div class="col-md-4 text-end">
                                <?php if ($booking['status'] == 'pending'): ?>
                                    <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=confirm"
                                        class="btn btn-success w-100 mb-2"><i class="fas fa-check me-2"></i>Confirm Booking</a>
                                    <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=cancel"
                                        class="btn btn-outline-danger w-100" onclick="return confirm('Decline this booking?')"><i class="fas fa-times me-2"></i>Decline</a>
                                <?php elseif ($booking['status'] == 'confirmed'): ?>
                                    <a href="chat.php?booking_id=<?php echo $booking['id']; ?>"
                                        class="btn btn-primary w-100 mb-2"><i class="fas fa-comments me-2"></i>Chat with Client</a>
                                    <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=complete"
                                        class="btn btn-info text-white w-100"><i class="fas fa-check-circle me-2"></i>Mark Complete</a>
                                <?php elseif ($booking['status'] == 'completed'): ?>
                                    <div class="alert alert-success mb-0">
                                        <i class="fas fa-check-circle me-2"></i>Completed
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">No actions available</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">No bookings yet</h4>
            <p class="text-muted">Bookings will appear here once users request your services.</p>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>