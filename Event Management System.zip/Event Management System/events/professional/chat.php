<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
checkProfessionalLogin();

if (!isset($_GET['booking_id']))
    redirect('bookings.php');
$booking_id = $_GET['booking_id'];

// Get User Info
$stmt = $pdo->prepare("SELECT u.id, u.name FROM bookings b JOIN users u ON b.user_id = u.id WHERE b.id = ?");
$stmt->execute([$booking_id]);
$user = $stmt->fetch();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'All Bookings', 'url' => 'bookings.php'],
    ['name' => 'Chat', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-header bg-white border-0 py-3">
                    <div class="d-flex align-items-center">
                        <div class="bg-success text-white rounded-circle p-2 me-3"
                            style="width: 40px; height: 40px; text-align: center;">
                            <i class="fas fa-user-circle"></i>
                        </div>
                        <h5 class="mb-0 fw-bold">Chat with <?php echo $user['name']; ?></h5>
                    </div>
                </div>
                <div class="card-body bg-light" style="height: 400px; overflow-y: scroll;" id="chat-box">
                    <div class="text-center text-muted mt-5">Loading messages...</div>
                </div>
                <div class="card-footer bg-white border-0 py-3">
                    <form id="chat-form" class="d-flex">
                        <input type="hidden" name="receiver_id" value="<?php echo $user['id']; ?>">
                        <input type="hidden" name="receiver_type" value="user">
                        <input type="text" name="message" id="message-input" class="form-control rounded-pill me-2"
                            placeholder="Type a message..." required autocomplete="off">
                        <button type="submit" class="btn btn-primary rounded-circle"><i
                                class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        var bookingId = <?php echo $booking_id; ?>;

        function loadMessages() {
            $.get('../api/chat_handler.php?booking_id=' + bookingId, function (data) {
                var msgs = JSON.parse(data);
                var html = '';
                msgs.forEach(function (m) {
                    var align = m.is_me ? 'text-end' : 'text-start';
                    var bg = m.is_me ? 'bg-primary text-white' : 'bg-white text-dark shadow-sm';

                    html += '<div class="' + align + ' mb-3">';
                    html += '<div class="d-inline-block p-3 rounded-3 ' + bg + '" style="max-width: 75%;">';
                    html += m.message;
                    html += '</div>';
                    html += '<div class="small text-muted mt-1">' + m.time + '</div>';
                    html += '</div>';
                });
                $('#chat-box').html(html);
            });
        }

        loadMessages();
        setInterval(loadMessages, 3000);

        $('#chat-form').submit(function (e) {
            e.preventDefault();
            var msg = $('#message-input').val();
            if (!msg.trim()) return;

            $.post('../api/chat_handler.php', $(this).serialize() + '&action=send', function (res) {
                $('#message-input').val('');
                loadMessages();
            });
        });
    });
</script>

<?php include '../includes/footer.php'; ?>