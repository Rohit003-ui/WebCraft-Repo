<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];

// Handle Deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM events WHERE id = ? AND professional_id = ?");
    $stmt->execute([$id, $pro_id]);
    header("Location: manage_events.php");
}

$stmt = $pdo->prepare("SELECT e.*, c.name as category_name FROM events e JOIN categories c ON e.category_id = c.id WHERE e.professional_id = ? ORDER BY e.created_at DESC");
$stmt->execute([$pro_id]);
$events = $stmt->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'My Events', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">My Events / Services</h2>
        <a href="create_event.php" class="btn btn-primary-gradient"><i class="fas fa-plus"></i> Add New</a>
    </div>

    <div class="row g-4">
        <?php foreach ($events as $event): ?>
            <div class="col-md-4">
                <div class="card event-card h-100">
                    <img src="<?php echo getEventImage($event['image'], $event['category_name'], '../'); ?>"
                        class="event-img" alt="<?php echo htmlspecialchars($event['title']); ?>">
                    <div class="card-body">
                        <h5 class="card-title fw-bold"><?php echo htmlspecialchars($event['title']); ?></h5>
                        <p class="text-primary fw-bold">₹<?php echo number_format($event['price']); ?></p>
                        <p class="text-muted small"><?php echo substr($event['description'], 0, 100); ?>...</p>
                        <div class="d-flex justify-content-between">
                            <a href="edit_event.php?id=<?php echo $event['id']; ?>"
                                class="btn btn-sm btn-outline-secondary">Edit</a>
                            <a href="?delete=<?php echo $event['id']; ?>" class="btn btn-sm btn-outline-danger"
                                onclick="return confirm('Are you sure?')">Delete</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include '../includes/footer.php'; ?>