<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Calculate Calendar Vars
$first_day = mktime(0, 0, 0, $month, 1, $year);
$days_in_month = date('t', $first_day);
$day_of_week = date('w', $first_day);
$month_name = date('F', $first_day);

// Fetch Bookings
$stmt = $pdo->prepare("SELECT booking_date FROM bookings WHERE professional_id = ? AND status = 'confirmed' AND MONTH(booking_date) = ? AND YEAR(booking_date) = ?");
$stmt->execute([$pro_id, $month, $year]);
$booked_dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Fetch Blocked Dates
$stmt = $pdo->prepare("SELECT blocked_date FROM blocked_dates WHERE professional_id = ? AND MONTH(blocked_date) = ? AND YEAR(blocked_date) = ?");
$stmt->execute([$pro_id, $month, $year]);
$blocked_dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Merge
$all_blocked = array_merge($booked_dates, $blocked_dates);

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Calendar', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">My Calendar</h2>
        <div>
            <a href="?month=<?php echo date('m', strtotime('-1 month', $first_day)); ?>&year=<?php echo date('Y', strtotime('-1 month', $first_day)); ?>"
                class="btn btn-outline-primary"><i class="fas fa-chevron-left"></i></a>
            <span class="mx-3 fw-bold fs-4"><?php echo "$month_name $year"; ?></span>
            <a href="?month=<?php echo date('m', strtotime('+1 month', $first_day)); ?>&year=<?php echo date('Y', strtotime('+1 month', $first_day)); ?>"
                class="btn btn-outline-primary"><i class="fas fa-chevron-right"></i></a>
        </div>
    </div>

    <div class="card shadow rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-bordered text-center mb-0" style="table-layout: fixed;">
                <thead class="bg-light">
                    <tr>
                        <th class="py-3">Sun</th>
                        <th class="py-3">Mon</th>
                        <th class="py-3">Tue</th>
                        <th class="py-3">Wed</th>
                        <th class="py-3">Thu</th>
                        <th class="py-3">Fri</th>
                        <th class="py-3">Sat</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <?php
                        // Empty cells before 1st day
                        for ($i = 0; $i < $day_of_week; $i++) {
                            echo "<td class='bg-light'></td>";
                        }

                        for ($day = 1; $day <= $days_in_month; $day++) {
                            $current_date = sprintf('%04d-%02d-%02d', $year, $month, $day);
                            $is_blocked = in_array($current_date, $all_blocked);
                            $bg_class = $is_blocked ? 'bg-danger text-white' : '';

                            echo "<td class='p-4 position-relative $bg_class' style='height: 100px; cursor: pointer;' onclick='toggleBlock(\"$current_date\")'>";
                            echo "<h5 class='fw-bold'>$day</h5>";
                            if ($is_blocked) {
                                echo "<small>Booked/Blocked</small>";
                            } else {
                                echo "<small class='text-muted'>Available</small>";
                            }
                            echo "</td>";

                            if (($day + $day_of_week) % 7 == 0) {
                                echo "</tr><tr>";
                            }
                        }

                        // Empty cells after last day
                        $remaining_days = (7 - ($days_in_month + $day_of_week) % 7) % 7;
                        for ($i = 0; $i < $remaining_days; $i++) {
                            echo "<td class='bg-light'></td>";
                        }
                        ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Block Date Modal -->
<div class="modal fade" id="blockModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="../api/block_date.php" method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Manage Date</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="date" id="selectedDate">
                    <p>Do you want to block or unblock <span id="displayDate" class="fw-bold"></span>?</p>
                    <div class="mb-3">
                        <label>Reason (if blocking)</label>
                        <input type="text" name="reason" class="form-control" placeholder="e.g. Personal Leave">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="action" value="unblock" class="btn btn-success">Unblock</button>
                    <button type="submit" name="action" value="block" class="btn btn-danger">Block Date</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function toggleBlock(date) {
        document.getElementById('selectedDate').value = date;
        document.getElementById('displayDate').innerText = date;
        new bootstrap.Modal(document.getElementById('blockModal')).show();
    }
</script>

<?php include '../includes/footer.php'; ?>