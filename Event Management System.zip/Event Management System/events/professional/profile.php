<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bio = cleanInput($_POST['bio']);
    $location = cleanInput($_POST['location']);

    // Handle Image
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $target_dir = "../assets/uploads/";
        $filename = time() . '_p_' . basename($_FILES["profile_image"]["name"]);
        $target_file = $target_dir . $filename;
        move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file);

        $stmt = $pdo->prepare("UPDATE professionals SET profile_image = ? WHERE id = ?");
        $stmt->execute([$filename, $pro_id]);
    }

    $stmt = $pdo->prepare("UPDATE professionals SET bio = ?, location = ? WHERE id = ?");
    $stmt->execute([$bio, $location, $pro_id]);
    $success = "Profile updated successfully!";
}

$stmt = $pdo->prepare("SELECT * FROM professionals WHERE id = ?");
$stmt->execute([$pro_id]);
$pro = $stmt->fetch();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Edit Profile', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow border-0 rounded-4">
                <div class="card-body p-5">
                    <h3 class="fw-bold mb-4">Edit Profile</h3>

                    <?php if ($success): ?>
                        <div class="alert alert-success"><?php echo $success; ?></div>
                    <?php endif; ?>

                    <form method="POST" enctype="multipart/form-data">
                        <div class="text-center mb-4">
                            <img src="<?php echo getProfessionalImage($pro['profile_image'], $pro['name'], '../'); ?>"
                                class="rounded-circle mb-3" width="100" height="100"
                                alt="<?php echo htmlspecialchars($pro['name']); ?>">
                            <input type="file" name="profile_image" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" value="<?php echo $pro['name']; ?>" class="form-control" disabled>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Bio (Tell users about yourself)</label>
                            <textarea name="bio" class="form-control" rows="4"><?php echo $pro['bio']; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <input type="text" name="location" value="<?php echo $pro['location']; ?>"
                                class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary-gradient w-100">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>