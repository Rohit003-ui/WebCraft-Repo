<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkProfessionalLogin();

if (!isset($_GET['id'])) {
    redirect('manage_events.php');
}

$event_id = $_GET['id'];
$pro_id = $_SESSION['professional_id'];

// Fetch Event Details
$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ? AND professional_id = ?");
$stmt->execute([$event_id, $pro_id]);
$event = $stmt->fetch();

if (!$event) {
    redirect('manage_events.php');
}

// Fetch Categories for Dropdown
$stmt = $pdo->query("SELECT * FROM categories");
$categories = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = cleanInput($_POST['title']);
    $desc = cleanInput($_POST['description']);
    $price = $_POST['price'];
    $cat_id = $_POST['category_id'];

    // Image Upload
    $image = $event['image']; // Default to existing
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../assets/uploads/";
        $filename = time() . '_' . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $filename;
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = $filename;
        }
    }

    $stmt = $pdo->prepare("UPDATE events SET title = ?, description = ?, category_id = ?, price = ?, image = ? WHERE id = ? AND professional_id = ?");
    $stmt->execute([$title, $desc, $cat_id, $price, $image, $event_id, $pro_id]);

    redirect('manage_events.php');
}

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'My Events', 'url' => 'manage_events.php'],
    ['name' => 'Edit Event', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-body p-5">
                    <h3 class="fw-bold mb-4">Edit Service/Event</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" required
                                value="<?php echo htmlspecialchars($event['title']); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select" required>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>" <?php echo $cat['id'] == $event['category_id'] ? 'selected' : ''; ?>>
                                        <?php echo $cat['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Price (₹)</label>
                            <input type="number" name="price" class="form-control" required
                                value="<?php echo $event['price']; ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control"
                                rows="4"><?php echo htmlspecialchars($event['description']); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Current Image</label>
                            <div class="mb-2">
                                <?php
                                // Get category name for placeholder
                                $cat_name = '';
                                foreach ($categories as $c)
                                    if ($c['id'] == $event['category_id'])
                                        $cat_name = $c['name'];
                                ?>
                                <img src="<?php echo getEventImage($event['image'], $cat_name, '../'); ?>"
                                    class="rounded border" width="200" alt="Current Image">
                            </div>
                            <label class="form-label">Update Image</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary-gradient px-4">Update Event</button>
                            <a href="manage_events.php" class="btn btn-outline-secondary px-4">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>