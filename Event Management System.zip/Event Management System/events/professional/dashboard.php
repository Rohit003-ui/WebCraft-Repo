<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];

// Fetch Statistics
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE professional_id = ? AND status = 'pending'");
$stmt->execute([$pro_id]);
$pending_bookings = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE professional_id = ? AND status = 'confirmed'");
$stmt->execute([$pro_id]);
$confirmed_bookings = $stmt->fetchColumn();

// Fetch Recent Bookings
$stmt = $pdo->prepare("
    SELECT b.*, u.name as user_name, e.title as event_title 
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN events e ON b.event_id = e.id
    WHERE b.professional_id = ?
    ORDER BY b.created_at DESC LIMIT 5
");
$stmt->execute([$pro_id]);
$recent_bookings = $stmt->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'Professional Dashboard', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 sidebar py-4 d-none d-md-block">
            <h5 class="fw-bold text-primary px-3 mb-4">Creator Panel</h5>
            <nav class="nav flex-column">
                <a class="nav-link active" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
                <a class="nav-link" href="manage_events.php"><i class="fas fa-calendar-plus me-2"></i> My Events</a>
                <a class="nav-link" href="bookings.php"><i class="fas fa-list-alt me-2"></i> All Bookings</a>
                <a class="nav-link" href="calendar.php"><i class="fas fa-calendar-alt me-2"></i> Calendar</a>
                <a class="nav-link" href="profile.php"><i class="fas fa-user-edit me-2"></i> Edit Profile</a>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="col-md-9 col-lg-10 py-4">
            <?php include '../includes/breadcrumb.php'; ?>
            <h2 class="fw-bold mb-4">Dashboard</h2>

            <div class="row g-4 mb-5">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning me-3">
                                <i class="fas fa-clock fa-2x"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-0">Pending Requests</h6>
                                <h3 class="fw-bold mb-0"><?php echo $pending_bookings; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm p-3">
                        <div class="d-flex align-items-center">
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success me-3">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                            <div>
                                <h6 class="text-muted mb-0">Confirmed Bookings</h6>
                                <h3 class="fw-bold mb-0"><?php echo $confirmed_bookings; ?></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Earnings could go here -->
            </div>

            <h4 class="fw-bold mb-3">Recent Booking Requests</h4>
            <div class="card border-0 shadow-sm">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>User</th>
                                <th>Event/Service</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_bookings as $booking): ?>
                                <tr>
                                    <td><?php echo $booking['user_name']; ?></td>
                                    <td><?php echo $booking['event_title']; ?></td>
                                    <td><?php echo $booking['booking_date']; ?></td>
                                    <td>
                                        <?php
                                        $badge = 'bg-secondary';
                                        if ($booking['status'] == 'confirmed')
                                            $badge = 'bg-success';
                                        if ($booking['status'] == 'pending')
                                            $badge = 'bg-warning text-dark';
                                        if ($booking['status'] == 'cancelled')
                                            $badge = 'bg-danger';
                                        ?>
                                        <span
                                            class="badge <?php echo $badge; ?> rounded-pill"><?php echo ucfirst($booking['status']); ?></span>
                                    </td>
                                    <td>
                                        <?php if ($booking['status'] == 'pending'): ?>
                                            <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=confirm"
                                                class="btn btn-sm btn-success rounded-pill"><i class="fas fa-check"></i></a>
                                            <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=cancel"
                                                class="btn btn-sm btn-danger rounded-pill"><i class="fas fa-times"></i></a>
                                        <?php else: ?>
                                            <a href="chat.php?booking_id=<?php echo $booking['id']; ?>"
                                                class="btn btn-sm btn-primary rounded-pill">Chat</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>