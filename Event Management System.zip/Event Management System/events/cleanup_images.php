<?php
require 'includes/db.php';
$pdo->query("UPDATE events SET image = REPLACE(image, 'assets/uploads/', '') WHERE image LIKE 'assets/uploads/%'");
$pdo->query("UPDATE professionals SET profile_image = REPLACE(profile_image, 'assets/uploads/', '') WHERE profile_image LIKE 'assets/uploads/%'");
echo "Cleaned up prefixes.\n";
?>