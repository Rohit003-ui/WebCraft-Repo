<?php
require 'includes/db.php';

echo "Updating events with highly relevant Unsplash images...\n";

$event_images = [
    'Complete Wedding Planning' => 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800',
    'Destination Wedding' => 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800',
    'Engagement Ceremony' => 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?w=800',
    'Traditional Wedding' => 'https://images.unsplash.com/photo-1519225495810-7512a3dfecf0?w=800',
    'Reception Party' => 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800',
    'Birthday Party' => 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=800',
    'Corporate Party' => 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800',
    'Theme Party' => 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800',
    'Kids Birthday' => 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=800',
    'Anniversary' => 'https://images.unsplash.com/photo-1513273395968-004313f8983e?w=800',
    'Live Concert' => 'https://images.unsplash.com/photo-1459749411177-042180ce673c?w=800',
    'Music Festival' => 'https://images.unsplash.com/photo-1493225255756-d9584f8606e9?w=800',
    'Fest Concert' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800',
    'Acoustic Night' => 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?w=800',
    'Training Seminar' => 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800',
    'Leadership Workshop' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800',
    'Technical Skill' => 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800',
    'Tech Summit' => 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800',
    'Business Conference' => 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800',
    'Medical Conference' => 'https://images.unsplash.com/photo-1576091160550-217359f4814c?w=800'
];

foreach ($event_images as $keyword => $url) {
    $stmt = $pdo->prepare("UPDATE events SET image = ? WHERE title LIKE ?");
    $stmt->execute([$url, "%$keyword%"]);
    echo "✓ Updated: $keyword\n";
}

echo "\nUpdating professionals with real-looking profile photos...\n";
$pro_images = [
    'Royal Wedding' => 'https://images.unsplash.com/photo-1519741497674-611481863552?w=400',
    'Dream Events' => 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=400',
    'Party Masters' => 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=400',
    'Celebration Hub' => 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400',
    'Live Music' => 'https://images.unsplash.com/photo-1459749411177-042180ce673c?w=400',
    'Sound & Stage' => 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=400',
    'Knowledge Hub' => 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400',
    'Business Pros' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=400',
    'Creative CoWork' => 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=400',
    'Global Conference' => 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400'
];

foreach ($pro_images as $keyword => $url) {
    $stmt = $pdo->prepare("UPDATE professionals SET profile_image = ? WHERE name LIKE ?");
    $stmt->execute([$url, "%$keyword%"]);
    echo "✓ Updated Pro: $keyword\n";
}

echo "\nCleaning up any null images to use placeholders...\n";
$pdo->query("UPDATE events SET image = NULL WHERE image = ''");
$pdo->query("UPDATE professionals SET profile_image = NULL WHERE profile_image = ''");

echo "\nDone!\n";
?>