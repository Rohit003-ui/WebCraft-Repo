<?php
echo "========================================\n";
echo "EventHub - Login & Image Fix Script\n";
echo "========================================\n\n";

require 'includes/db.php';

// Test 1: Check if passwords are set correctly
echo "1. Testing Login Credentials...\n";
$test_email = 'royal@eventhub.com';
$test_password = 'password123';

$stmt = $pdo->prepare("SELECT * FROM professionals WHERE email = ?");
$stmt->execute([$test_email]);
$pro = $stmt->fetch();

if ($pro) {
    echo "✓ Found professional: {$pro['name']}\n";
    if (password_verify($test_password, $pro['password'])) {
        echo "✓ Password verification works!\n";
        echo "  You can login with: $test_email / $test_password\n";
    } else {
        echo "✗ Password verification failed\n";
        echo "  Resetting password...\n";
        $new_hash = password_hash($test_password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE professionals SET password = ? WHERE email = ?")->execute([$new_hash, $test_email]);
        echo "✓ Password reset complete\n";
    }
} else {
    echo "✗ Professional not found\n";
}

// Test 2: Check session functionality
echo "\n2. Testing Session...\n";
session_start();
$_SESSION['test'] = 'working';
if (isset($_SESSION['test'])) {
    echo "✓ Session is working\n";
    unset($_SESSION['test']);
} else {
    echo "✗ Session not working\n";
}

// Test 3: Check upload directory
echo "\n3. Checking Upload Directory...\n";
if (!is_dir('assets/uploads')) {
    mkdir('assets/uploads', 0777, true);
    echo "✓ Created upload directory\n";
} else {
    echo "✓ Upload directory exists\n";
}

if (is_writable('assets/uploads')) {
    echo "✓ Upload directory is writable\n";
} else {
    echo "⚠ Upload directory is not writable\n";
    chmod('assets/uploads', 0777);
    echo "✓ Fixed permissions\n";
}

// Test 4: Check for actual uploaded images
echo "\n4. Checking Uploaded Images...\n";
$files = glob('assets/uploads/*');
if (count($files) > 0) {
    echo "✓ Found " . count($files) . " uploaded file(s)\n";
} else {
    echo "⚠ No uploaded images found (using placeholders)\n";
}

// Test 5: Update events with placeholder references
echo "\n5. Checking Events...\n";
$events = $pdo->query("SELECT id, title, image FROM events")->fetchAll();
echo "✓ Found " . count($events) . " event(s)\n";
$no_image = 0;
foreach ($events as $event) {
    if (!$event['image']) {
        $no_image++;
    }
}
echo "  $no_image event(s) without images (will use category placeholders)\n";

// Test 6: Test redirect function
echo "\n6. Testing Redirect Function...\n";
require_once 'includes/functions.php';
if (function_exists('redirect')) {
    echo "✓ Redirect function exists\n";
} else {
    echo "✗ Redirect function missing\n";
}

// Test 7: Check navbar file
echo "\n7. Checking Navbar...\n";
if (file_exists('includes/navbar.php')) {
    echo "✓ Navbar file exists\n";
    $navbar_content = file_get_contents('includes/navbar.php');
    if (strpos($navbar_content, 'Professionals') !== false) {
        echo "✓ Navbar has Professionals link\n";
    } else {
        echo "⚠ Navbar missing Professionals link\n";
    }
} else {
    echo "✗ Navbar file missing\n";
}

echo "\n========================================\n";
echo "QUICK FIX SUMMARY\n";
echo "========================================\n\n";

echo "✅ LOGIN FIX:\n";
echo "  Email: royal@eventhub.com\n";
echo "  Password: password123\n";
echo "  URL: http://localhost/for/pages/login.php\n\n";

echo "✅ IMAGE FIX:\n";
echo "  - Using category-based placeholders from Unsplash\n";
echo "  - Images will load automatically\n";
echo "  - No manual upload needed for testing\n\n";

echo "🔧 TO TEST LOGIN:\n";
echo "  1. Go to: http://localhost/for/pages/login.php\n";
echo "  2. Click 'Professional Login' tab\n";
echo "  3. Email: royal@eventhub.com\n";
echo "  4. Password: password123\n";
echo "  5. Click 'Login as Professional'\n\n";

echo "🔧 TO TEST IMAGES:\n";
echo "  1. Go to: http://localhost/for/pages/events.php\n";
echo "  2. Images should load from Unsplash\n";
echo "  3. Each category has different placeholder\n\n";

echo "========================================\n";
?>