<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkUserLogin();

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT b.*, p.name as professional_name, e.title as event_title 
    FROM bookings b
    JOIN professionals p ON b.professional_id = p.id
    JOIN events e ON b.event_id = e.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'User Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'My Bookings', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <h2 class="fw-bold mb-4">My Bookings</h2>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="py-3 ps-4">Event</th>
                        <th>Professional</th>
                        <th>Date & Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($bookings) > 0): ?>
                        <?php foreach ($bookings as $booking): ?>
                            <tr>
                                <td class="ps-4 fw-bold"><?php echo $booking['event_title']; ?></td>
                                <td><?php echo $booking['professional_name']; ?></td>
                                <td><?php echo $booking['booking_date'] . ' ' . date('h:i A', strtotime($booking['booking_time'])); ?>
                                </td>
                                <td>
                                    <?php
                                    $badge = 'bg-secondary';
                                    if ($booking['status'] == 'confirmed')
                                        $badge = 'bg-success';
                                    if ($booking['status'] == 'pending')
                                        $badge = 'bg-warning text-dark';
                                    if ($booking['status'] == 'cancelled')
                                        $badge = 'bg-danger';
                                    ?>
                                    <span
                                        class="badge <?php echo $badge; ?> rounded-pill"><?php echo ucfirst($booking['status']); ?></span>
                                </td>
                                <td>
                                    <?php if ($booking['status'] == 'pending'): ?>
                                        <a href="../api/booking_action.php?id=<?php echo $booking['id']; ?>&action=cancel_user"
                                            class="btn btn-sm btn-outline-danger rounded-pill"
                                            onclick="return confirm('Cancel this booking?')">Cancel</a>
                                    <?php elseif ($booking['status'] == 'confirmed'): ?>
                                        <a href="chat.php?booking_id=<?php echo $booking['id']; ?>"
                                            class="btn btn-sm btn-primary rounded-pill"><i class="fas fa-comments"></i> Chat</a>
                                    <?php elseif ($booking['status'] == 'completed'): ?>
                                        <a href="review.php?booking_id=<?php echo $booking['id']; ?>"
                                            class="btn btn-sm btn-warning text-dark rounded-pill"><i class="fas fa-star"></i>
                                            Review</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">No bookings yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>