<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
require '../includes/image_helpers.php';
checkUserLogin();

$user_id = $_SESSION['user_id'];

// Stats
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE user_id = ?");
$stmt->execute([$user_id]);
$total_bookings = $stmt->fetchColumn();

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'User Dashboard', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="row">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm p-4 text-center">
                <img src="<?php echo getProfessionalImage('', $_SESSION['user_name'], '../'); ?>"
                    class="rounded-circle mb-3 mx-auto" width="80" height="80"
                    alt="<?php echo htmlspecialchars($_SESSION['user_name']); ?>">
                <h5 class="fw-bold"><?php echo $_SESSION['user_name']; ?></h5>
                <p class="text-muted small">User</p>
                <hr>
                <ul class="list-unstyled text-start">
                    <li class="mb-2"><a href="dashboard.php" class="text-primary text-decoration-none fw-bold"><i
                                class="fas fa-home me-2"></i> Dashboard</a></li>
                    <li class="mb-2"><a href="my_bookings.php" class="text-dark text-decoration-none"><i
                                class="fas fa-calendar-check me-2"></i> My Bookings</a></li>
                    <li><a href="../api/logout.php" class="text-danger text-decoration-none"><i
                                class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="col-md-9">
            <h2 class="fw-bold mb-4">Dashboard</h2>
            <div class="row mb-5">
                <div class="col-md-4">
                    <div class="card bg-primary text-white p-4 border-0 rounded-4 shadow-sm">
                        <h3><?php echo $total_bookings; ?></h3>
                        <p class="mb-0">Total Bookings</p>
                    </div>
                </div>
            </div>

            <h4 class="fw-bold mb-3">Recent Activity</h4>
            <div class="alert alert-info border-0 text-center py-5">
                <i class="fas fa-history fa-2x mb-3 opacity-50"></i>
                <p>Check "My Bookings" for details.</p>
                <a href="my_bookings.php" class="btn btn-sm btn-light rounded-pill">View Bookings</a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>