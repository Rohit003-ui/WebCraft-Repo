<?php
$path = '../';
require '../includes/db.php';
require '../includes/functions.php';
checkUserLogin();

if (!isset($_GET['booking_id']))
    redirect('my_bookings.php');
$booking_id = $_GET['booking_id'];

// Check validity
$stmt = $pdo->prepare("SELECT b.*, p.name as professional_name FROM bookings b JOIN professionals p ON b.professional_id = p.id WHERE b.id = ? AND b.user_id = ? AND b.status = 'completed'");
$stmt->execute([$booking_id, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    die("Invalid request or booking not completed.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $comment = cleanInput($_POST['comment']);

    $stmt = $pdo->prepare("INSERT INTO reviews (booking_id, user_id, professional_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$booking_id, $_SESSION['user_id'], $booking['professional_id'], $rating, $comment]);

    redirect('my_bookings.php');
}

// Set breadcrumbs
$breadcrumbs = [
    ['name' => 'Home', 'url' => '../index.php'],
    ['name' => 'User Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'My Bookings', 'url' => 'my_bookings.php'],
    ['name' => 'Write Review', 'url' => '']
];

include '../includes/header.php';
?>

<div class="container py-5">
    <?php include '../includes/breadcrumb.php'; ?>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow p-4 border-0">
                <h3 class="fw-bold mb-3">Review for <?php echo $booking['professional_name']; ?></h3>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Rating</label>
                        <select name="rating" class="form-select">
                            <option value="5">5 - Excellent</option>
                            <option value="4">4 - Good</option>
                            <option value="3">3 - Average</option>
                            <option value="2">2 - Poor</option>
                            <option value="1">1 - Terrible</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Comment</label>
                        <textarea name="comment" class="form-control" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary-gradient w-100">Submit Review</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>