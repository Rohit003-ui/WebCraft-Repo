<?php
require 'includes/db.php';

echo "Starting data seeding...\n\n";

// Sample professionals data
$professionals = [
    [
        'name' => 'Royal Wedding Planners',
        'email' => 'royal@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Function',
        'bio' => 'Premium wedding planning services with 10+ years of experience. We specialize in destination weddings and luxury events.',
        'location' => 'Mumbai, Maharashtra',
        'profile_image' => null
    ],
    [
        'name' => 'Dream Events Co.',
        'email' => 'dream@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Function',
        'bio' => 'Making your dream wedding a reality. Expert team handling everything from decor to catering.',
        'location' => 'Delhi, NCR',
        'profile_image' => null
    ],
    [
        'name' => 'Party Masters',
        'email' => 'party@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Party',
        'bio' => 'The ultimate party organizers! Birthday parties, corporate parties, theme parties - we do it all.',
        'location' => 'Bangalore, Karnataka',
        'profile_image' => null
    ],
    [
        'name' => 'Celebration Hub',
        'email' => 'celebration@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Party',
        'bio' => 'Creating unforgettable celebrations since 2015. Specializing in kids parties and milestone celebrations.',
        'location' => 'Pune, Maharashtra',
        'profile_image' => null
    ],
    [
        'name' => 'Live Music Productions',
        'email' => 'livemusic@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Concert',
        'bio' => 'Professional concert management and live music events. We have hosted 100+ successful concerts.',
        'location' => 'Mumbai, Maharashtra',
        'profile_image' => null
    ],
    [
        'name' => 'Sound & Stage',
        'email' => 'soundstage@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Concert',
        'bio' => 'Complete concert production services including sound, lighting, and stage management.',
        'location' => 'Hyderabad, Telangana',
        'profile_image' => null
    ],
    [
        'name' => 'Knowledge Hub',
        'email' => 'knowledge@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Seminar',
        'bio' => 'Professional seminar and workshop organizers. Specializing in corporate training and educational events.',
        'location' => 'Bangalore, Karnataka',
        'profile_image' => null
    ],
    [
        'name' => 'Edu Events',
        'email' => 'eduevents@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Seminar',
        'bio' => 'Educational seminar specialists with expertise in academic conferences and skill development workshops.',
        'location' => 'Chennai, Tamil Nadu',
        'profile_image' => null
    ],
    [
        'name' => 'CoWork Spaces',
        'email' => 'cowork@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Workspace',
        'bio' => 'Modern coworking spaces with all amenities. Perfect for startups, freelancers, and remote teams.',
        'location' => 'Gurgaon, Haryana',
        'profile_image' => null
    ],
    [
        'name' => 'Global Conference Organizers',
        'email' => 'global@eventhub.com',
        'password' => password_hash('password123', PASSWORD_DEFAULT),
        'category' => 'Conference',
        'bio' => 'International conference management with experience in tech summits, medical conferences, and business forums.',
        'location' => 'Mumbai, Maharashtra',
        'profile_image' => null
    ]
];

// Insert professionals
$pro_ids = [];
foreach ($professionals as $pro) {
    try {
        $stmt = $pdo->prepare("INSERT INTO professionals (name, email, password, category, bio, location, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$pro['name'], $pro['email'], $pro['password'], $pro['category'], $pro['bio'], $pro['location'], $pro['profile_image']]);
        $pro_ids[] = $pdo->lastInsertId();
        echo "✓ Created professional: {$pro['name']}\n";
    } catch (PDOException $e) {
        echo "✗ Failed to create {$pro['name']}: " . $e->getMessage() . "\n";
    }
}

echo "\n";

// Get category IDs
$categories = $pdo->query("SELECT name, id FROM categories")->fetchAll(PDO::FETCH_KEY_PAIR);

// Sample events for each professional
$events = [
    // Royal Wedding Planners (Function)
    ['pro_idx' => 0, 'title' => 'Complete Wedding Planning Package', 'desc' => 'Full-service wedding planning including venue, catering, decoration, photography, and coordination. Perfect for grand weddings.', 'category' => 'Function', 'price' => 150000],
    ['pro_idx' => 0, 'title' => 'Destination Wedding Package', 'desc' => 'Exotic destination wedding planning with travel arrangements, accommodation, and complete event management.', 'category' => 'Function', 'price' => 300000],
    ['pro_idx' => 0, 'title' => 'Engagement Ceremony Planning', 'desc' => 'Beautiful engagement ceremony setup with decoration, catering, and entertainment arrangements.', 'category' => 'Function', 'price' => 50000],

    // Dream Events Co. (Function)
    ['pro_idx' => 1, 'title' => 'Traditional Wedding Package', 'desc' => 'Traditional wedding planning with cultural rituals, mandap decoration, and authentic catering.', 'category' => 'Function', 'price' => 120000],
    ['pro_idx' => 1, 'title' => 'Reception Party Planning', 'desc' => 'Grand reception party with DJ, lighting, catering, and complete venue management.', 'category' => 'Function', 'price' => 80000],

    // Party Masters (Party)
    ['pro_idx' => 2, 'title' => 'Birthday Party Package', 'desc' => 'Complete birthday party setup with theme decoration, games, entertainment, and catering for 50 guests.', 'category' => 'Party', 'price' => 25000],
    ['pro_idx' => 2, 'title' => 'Corporate Party Planning', 'desc' => 'Professional corporate party organization with team activities, catering, and entertainment.', 'category' => 'Party', 'price' => 75000],
    ['pro_idx' => 2, 'title' => 'Theme Party Package', 'desc' => 'Customized theme party with decoration, costumes, props, and entertainment based on your choice.', 'category' => 'Party', 'price' => 40000],

    // Celebration Hub (Party)
    ['pro_idx' => 3, 'title' => 'Kids Birthday Bash', 'desc' => 'Fun-filled kids birthday party with games, magic show, balloon decoration, and cake.', 'category' => 'Party', 'price' => 15000],
    ['pro_idx' => 3, 'title' => 'Anniversary Celebration', 'desc' => 'Romantic anniversary celebration setup with decoration, candlelight dinner, and photography.', 'category' => 'Party', 'price' => 30000],

    // Live Music Productions (Concert)
    ['pro_idx' => 4, 'title' => 'Live Concert Production', 'desc' => 'Complete concert production with sound system, stage setup, lighting, and artist coordination.', 'category' => 'Concert', 'price' => 200000],
    ['pro_idx' => 4, 'title' => 'Music Festival Management', 'desc' => 'Multi-day music festival organization with multiple stages, artist management, and logistics.', 'category' => 'Concert', 'price' => 500000],
    ['pro_idx' => 4, 'title' => 'College Fest Concert', 'desc' => 'College festival concert with popular artists, sound system, and stage management.', 'category' => 'Concert', 'price' => 150000],

    // Sound & Stage (Concert)
    ['pro_idx' => 5, 'title' => 'Corporate Event Concert', 'desc' => 'Professional concert setup for corporate events with premium sound and lighting.', 'category' => 'Concert', 'price' => 180000],
    ['pro_idx' => 5, 'title' => 'Acoustic Night Setup', 'desc' => 'Intimate acoustic performance setup with quality sound system and ambient lighting.', 'category' => 'Concert', 'price' => 50000],

    // Knowledge Hub (Seminar)
    ['pro_idx' => 6, 'title' => 'Corporate Training Seminar', 'desc' => 'Professional training seminar with expert speakers, venue, and training materials for 100 participants.', 'category' => 'Seminar', 'price' => 60000],
    ['pro_idx' => 6, 'title' => 'Leadership Workshop', 'desc' => 'Interactive leadership development workshop with activities, case studies, and certification.', 'category' => 'Seminar', 'price' => 45000],
    ['pro_idx' => 6, 'title' => 'Technical Skill Seminar', 'desc' => 'Hands-on technical training seminar with lab setup, expert trainers, and course materials.', 'category' => 'Seminar', 'price' => 55000],

    // Edu Events (Seminar)
    ['pro_idx' => 7, 'title' => 'Academic Conference', 'desc' => 'Multi-day academic conference with keynote speakers, paper presentations, and networking sessions.', 'category' => 'Seminar', 'price' => 100000],
    ['pro_idx' => 7, 'title' => 'Student Career Seminar', 'desc' => 'Career guidance seminar for students with industry experts, resume workshops, and mock interviews.', 'category' => 'Seminar', 'price' => 30000],

    // CoWork Spaces (Workspace)
    ['pro_idx' => 8, 'title' => 'Monthly Coworking Desk', 'desc' => 'Dedicated desk in premium coworking space with high-speed internet, meeting rooms, and amenities.', 'category' => 'Workspace', 'price' => 8000],
    ['pro_idx' => 8, 'title' => 'Private Office Space', 'desc' => 'Fully furnished private office for 5-10 people with 24/7 access and all facilities.', 'category' => 'Workspace', 'price' => 50000],
    ['pro_idx' => 8, 'title' => 'Meeting Room Rental', 'desc' => 'Professional meeting room rental with projector, whiteboard, and refreshments for 20 people.', 'category' => 'Workspace', 'price' => 5000],

    // Global Conference Organizers (Conference)
    ['pro_idx' => 9, 'title' => 'International Tech Summit', 'desc' => 'Large-scale tech conference with international speakers, exhibition area, and networking events.', 'category' => 'Conference', 'price' => 800000],
    ['pro_idx' => 9, 'title' => 'Business Conference', 'desc' => 'Professional business conference with panel discussions, workshops, and networking opportunities.', 'category' => 'Conference', 'price' => 250000],
    ['pro_idx' => 9, 'title' => 'Medical Conference', 'desc' => 'Medical professionals conference with CME credits, expert sessions, and exhibition.', 'category' => 'Conference', 'price' => 350000]
];

// Insert events
foreach ($events as $event) {
    $pro_id = $pro_ids[$event['pro_idx']];
    $cat_id = $categories[$event['category']];

    try {
        $stmt = $pdo->prepare("INSERT INTO events (professional_id, title, description, category_id, price) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$pro_id, $event['title'], $event['desc'], $cat_id, $event['price']]);
        echo "✓ Created event: {$event['title']}\n";
    } catch (PDOException $e) {
        echo "✗ Failed to create event: " . $e->getMessage() . "\n";
    }
}

echo "\n✅ SEEDING COMPLETE!\n\n";
echo "Sample Professional Credentials:\n";
echo "================================\n";
foreach ($professionals as $pro) {
    echo "Email: {$pro['email']} | Password: password123\n";
}
echo "\nYou can now login with any of these accounts!\n";
?>