<?php
session_start();

function isLoggedIn()
{
    return isset($_SESSION['user_id']) || isset($_SESSION['professional_id']);
}

function redirect($url)
{
    // Clean any output buffers
    if (ob_get_level()) {
        ob_end_clean();
    }

    header("Location: $url");
    exit();
}

function cleanInput($data)
{
    return htmlspecialchars(stripslashes(trim($data)));
}

function checkUserLogin()
{
    if (!isset($_SESSION['user_id'])) {
        redirect('../pages/login.php');
    }
}

function checkProfessionalLogin()
{
    if (!isset($_SESSION['professional_id'])) {
        redirect('../pages/login.php');
    }
}

// Helper function to get base URL
function getBaseUrl()
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $path = dirname(dirname($script));
    return $protocol . "://" . $host . $path;
}
?>