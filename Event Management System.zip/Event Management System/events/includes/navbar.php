<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$p = isset($path) ? $path : '../';
?>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo $p; ?>index.php">
            <i class="fas fa-calendar-check me-2"></i>EventHub
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link" href="<?php echo $p; ?>index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $p; ?>pages/events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link"
                        href="<?php echo $p; ?>pages/professionals.php">Professionals</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo $p; ?>pages/contact.php">Contact</a></li>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo $p; ?>user/dashboard.php"><i
                                        class="fas fa-home me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>user/my_bookings.php"><i
                                        class="fas fa-calendar me-2"></i>My Bookings</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>user/favorites.php"><i
                                        class="fas fa-heart me-2"></i>Favorites</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item text-danger" href="<?php echo $p; ?>api/logout.php"><i
                                        class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php elseif (isset($_SESSION['professional_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-briefcase me-1"></i>
                            <?php echo htmlspecialchars($_SESSION['professional_name']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?php echo $p; ?>professional/dashboard.php"><i
                                        class="fas fa-home me-2"></i>Dashboard</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>professional/manage_events.php"><i
                                        class="fas fa-calendar-plus me-2"></i>My Events</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>professional/bookings.php"><i
                                        class="fas fa-list-alt me-2"></i>All Bookings</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>professional/calendar.php"><i
                                        class="fas fa-calendar-alt me-2"></i>Calendar</a></li>
                            <li><a class="dropdown-item" href="<?php echo $p; ?>professional/profile.php"><i
                                        class="fas fa-user-edit me-2"></i>Edit Profile</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item text-danger" href="<?php echo $p; ?>api/logout.php"><i
                                        class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item ms-2">
                        <a class="btn btn-outline-primary rounded-pill px-4"
                            href="<?php echo $p; ?>pages/login.php">Login</a>
                    </li>
                    <li class="nav-item ms-2">
                        <a class="btn btn-primary-gradient" href="<?php echo $p; ?>pages/register.php">Sign Up</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div style="margin-top: 80px;"></div>