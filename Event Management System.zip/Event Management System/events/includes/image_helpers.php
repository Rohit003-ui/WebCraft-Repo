<?php
/**
 * Image Helper Functions
 */

// Category-based placeholder images from Unsplash
function getCategoryPlaceholder($category)
{
    $placeholders = [
        'Function' => 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&h=600&fit=crop', // Wedding/Event Hall
        'Party' => 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&h=600&fit=crop', // Party/People
        'Concert' => 'https://images.unsplash.com/photo-1459749411177-042180ce673c?w=800&h=600&fit=crop', // Concert
        'Seminar' => 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&h=600&fit=crop', // Seminar
        'Workspace' => 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=600&fit=crop', // Workspace
        'Conference' => 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=600&fit=crop'  // Conference
    ];

    return $placeholders[$category] ?? 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&h=400&fit=crop';
}

// Get event image with fallback
function getEventImage($event_image, $category, $path = '../')
{
    if ($event_image) {
        if (strpos($event_image, 'http') === 0) {
            return $event_image;
        }
        if (file_exists($path . 'assets/uploads/' . $event_image)) {
            return $path . 'assets/uploads/' . $event_image;
        }
    }
    return getCategoryPlaceholder($category);
}

// Get professional image with fallback
function getProfessionalImage($profile_image, $name, $path = '../')
{
    if ($profile_image) {
        if (strpos($profile_image, 'http') === 0) {
            return $profile_image;
        }
        if (file_exists($path . 'assets/uploads/' . $profile_image)) {
            return $path . 'assets/uploads/' . $profile_image;
        }
    }
    return 'https://ui-avatars.com/api/?name=' . urlencode($name) . '&size=200&background=random&color=fff';
}
?>