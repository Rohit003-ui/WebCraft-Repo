<?php
/**
 * Breadcrumb Component
 * Usage: include 'includes/breadcrumb.php';
 * Set $breadcrumbs array before including this file
 * Example: $breadcrumbs = [
 *     ['name' => 'Home', 'url' => 'index.php'],
 *     ['name' => 'Events', 'url' => 'pages/events.php'],
 *     ['name' => 'Event Details', 'url' => '']
 * ];
 */

if (!isset($breadcrumbs) || empty($breadcrumbs)) {
    return;
}
?>
<nav aria-label="breadcrumb" class="mb-3">
    <ol class="breadcrumb bg-light p-3 rounded">
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
            <?php if ($index === count($breadcrumbs) - 1): ?>
                <li class="breadcrumb-item active" aria-current="page">
                    <?php echo htmlspecialchars($crumb['name']); ?>
                </li>
            <?php else: ?>
                <li class="breadcrumb-item">
                    <a href="<?php echo $crumb['url']; ?>"><?php echo htmlspecialchars($crumb['name']); ?></a>
                </li>
            <?php endif; ?>
        <?php endforeach; ?>
    </ol>
</nav>