<?php $p = isset($path) ? $path : '../'; ?>
<footer class="bg-dark text-light py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h4 class="text-primary fw-bold">EventHub</h4>
                <p class="text-secondary">Your one-stop solution for perfect event planning. Connect with top
                    professionals and create memories.</p>
            </div>
            <div class="col-md-4 mb-4">
                <h5 class="mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="<?php echo $p; ?>index.php" class="text-secondary text-decoration-none">Home</a></li>
                    <li><a href="<?php echo $p; ?>pages/events.php" class="text-secondary text-decoration-none">Browse Events</a></li>
                    <li><a href="<?php echo $p; ?>pages/login.php" class="text-secondary text-decoration-none">Login</a></li>
                    <li><a href="<?php echo $p; ?>pages/contact.php" class="text-secondary text-decoration-none">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h5 class="mb-3">Contact Info</h5>
                <p class="text-secondary"><i class="fas fa-envelope me-2"></i> support@eventhub.com</p>
                <p class="text-secondary"><i class="fas fa-phone me-2"></i> +1 234 567 890</p>
                <div class="mt-3">
                    <a href="#" class="text-light me-3"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-instagram fa-lg"></i></a>
                </div>
            </div>
        </div>
        <hr class="border-secondary">
        <div class="text-center text-secondary">
            <small>&copy; <?php echo date('Y'); ?> EventHub. All rights reserved.</small>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="<?php echo $p; ?>assets/js/main.js"></script>
</body></html>