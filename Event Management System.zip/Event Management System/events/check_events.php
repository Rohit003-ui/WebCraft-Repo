<?php
require 'includes/db.php';
$events = $pdo->query('SELECT title, image FROM events')->fetchAll();
foreach ($events as $e) {
    echo "Title: " . $e['title'] . " | Image: " . $e['image'] . "\n";
}
?>