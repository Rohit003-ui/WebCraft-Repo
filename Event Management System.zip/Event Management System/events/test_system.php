<?php
require 'includes/db.php';

echo "========================================\n";
echo "EventHub System Test\n";
echo "========================================\n\n";

$errors = [];
$warnings = [];
$success = [];

// Test 1: Database Connection
echo "1. Testing Database Connection...\n";
try {
    $pdo->query("SELECT 1");
    $success[] = "✓ Database connection successful";
} catch (PDOException $e) {
    $errors[] = "✗ Database connection failed: " . $e->getMessage();
}

// Test 2: Check Tables
echo "\n2. Checking Database Tables...\n";
$required_tables = ['users', 'professionals', 'categories', 'events', 'bookings', 'blocked_dates', 'messages', 'reviews', 'notifications', 'transactions'];
foreach ($required_tables as $table) {
    $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
    if ($stmt->rowCount() > 0) {
        $success[] = "✓ Table '$table' exists";
    } else {
        $errors[] = "✗ Table '$table' missing";
    }
}

// Test 3: Check Sample Data
echo "\n3. Checking Sample Data...\n";
$pro_count = $pdo->query("SELECT COUNT(*) FROM professionals")->fetchColumn();
$event_count = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$cat_count = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();

if ($pro_count > 0) {
    $success[] = "✓ Found $pro_count professional(s)";
} else {
    $warnings[] = "⚠ No professionals found - run seed_data.php";
}

if ($event_count > 0) {
    $success[] = "✓ Found $event_count event(s)";
} else {
    $warnings[] = "⚠ No events found - run add_events.php";
}

if ($cat_count > 0) {
    $success[] = "✓ Found $cat_count categor(ies)";
} else {
    $errors[] = "✗ No categories found";
}

// Test 4: Check Required Files
echo "\n4. Checking Required Files...\n";
$required_files = [
    'index.php',
    'includes/db.php',
    'includes/functions.php',
    'includes/navbar.php',
    'includes/footer.php',
    'includes/breadcrumb.php',
    'pages/events.php',
    'pages/event_details.php',
    'pages/professionals.php',
    'pages/professional_profile.php',
    'pages/login.php',
    'pages/register.php',
    'professional/dashboard.php',
    'professional/bookings.php',
    'user/dashboard.php',
    'user/my_bookings.php'
];

foreach ($required_files as $file) {
    if (file_exists($file)) {
        $success[] = "✓ File '$file' exists";
    } else {
        $errors[] = "✗ File '$file' missing";
    }
}

// Test 5: Check Booking Columns
echo "\n5. Checking Booking Table Columns...\n";
$booking_columns = $pdo->query("DESCRIBE bookings")->fetchAll(PDO::FETCH_COLUMN);
$required_booking_cols = ['guest_count', 'venue_address', 'special_requirements', 'total_amount', 'platform_fee', 'professional_amount', 'payment_status'];

foreach ($required_booking_cols as $col) {
    if (in_array($col, $booking_columns)) {
        $success[] = "✓ Column 'bookings.$col' exists";
    } else {
        $errors[] = "✗ Column 'bookings.$col' missing - run update_schema.php";
    }
}

// Test 6: Check Image Directories
echo "\n6. Checking Image Directories...\n";
if (is_dir('assets/uploads')) {
    $success[] = "✓ Upload directory exists";
    if (is_writable('assets/uploads')) {
        $success[] = "✓ Upload directory is writable";
    } else {
        $warnings[] = "⚠ Upload directory is not writable";
    }
} else {
    $warnings[] = "⚠ Upload directory missing - creating...";
    mkdir('assets/uploads', 0777, true);
}

// Print Results
echo "\n========================================\n";
echo "TEST RESULTS\n";
echo "========================================\n\n";

if (count($success) > 0) {
    echo "✅ SUCCESS (" . count($success) . "):\n";
    foreach ($success as $msg) {
        echo "  $msg\n";
    }
    echo "\n";
}

if (count($warnings) > 0) {
    echo "⚠️  WARNINGS (" . count($warnings) . "):\n";
    foreach ($warnings as $msg) {
        echo "  $msg\n";
    }
    echo "\n";
}

if (count($errors) > 0) {
    echo "❌ ERRORS (" . count($errors) . "):\n";
    foreach ($errors as $msg) {
        echo "  $msg\n";
    }
    echo "\n";
}

// Final Summary
echo "========================================\n";
if (count($errors) == 0) {
    echo "✅ ALL CRITICAL TESTS PASSED!\n";
    echo "\nYou can now:\n";
    echo "1. Open http://localhost/for/index.php\n";
    echo "2. Login with: royal@eventhub.com / password123\n";
    echo "3. Test all features\n";
} else {
    echo "❌ SOME TESTS FAILED\n";
    echo "\nPlease fix the errors above before proceeding.\n";
}
echo "========================================\n";
?>