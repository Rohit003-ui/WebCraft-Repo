<?php
require 'includes/db.php';

// Fetch all professionals
$pros = $pdo->query("SELECT id, name, email, category FROM professionals ORDER BY id")->fetchAll();

// Fetch all users
$users = $pdo->query("SELECT id, name, email FROM users ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventHub - Account Credentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="bg-light">
    <div class="container py-5">
        <div class="text-center mb-5">
            <h1 class="fw-bold"><i class="fas fa-key text-primary me-2"></i>EventHub Test Credentials</h1>
            <p class="text-muted">All accounts use password: <code
                    class="bg-warning px-2 py-1 rounded">password123</code></p>
        </div>

        <!-- Professional Accounts -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="fas fa-briefcase me-2"></i>Professional Accounts
                    (<?php echo count($pros); ?>)</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Category</th>
                                <th>Password</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pros as $pro): ?>
                                <tr>
                                    <td><?php echo $pro['id']; ?></td>
                                    <td><?php echo $pro['name']; ?></td>
                                    <td><code><?php echo $pro['email']; ?></code></td>
                                    <td><span class="badge bg-info"><?php echo $pro['category']; ?></span></td>
                                    <td><strong class="text-success">password123</strong></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary"
                                            onclick="copyCredentials('<?php echo $pro['email']; ?>', 'password123')">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- User Accounts -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0"><i class="fas fa-users me-2"></i>User Accounts (<?php echo count($users); ?>)</h4>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo $user['name']; ?></td>
                                    <td><code><?php echo $user['email']; ?></code></td>
                                    <td><strong class="text-success">password123</strong></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-success"
                                            onclick="copyCredentials('<?php echo $user['email']; ?>', 'password123')">
                                            <i class="fas fa-copy"></i> Copy
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="fw-bold mb-3">Quick Actions</h5>
                <div class="row g-3">
                    <div class="col-md-4">
                        <a href="pages/login.php" class="btn btn-primary w-100">
                            <i class="fas fa-sign-in-alt me-2"></i>Go to Login Page
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="index.php" class="btn btn-outline-primary w-100">
                            <i class="fas fa-home me-2"></i>Go to Homepage
                        </a>
                    </div>
                    <div class="col-md-4">
                        <button class="btn btn-warning w-100"
                            onclick="if(confirm('Reset all passwords to password123?')) window.location.href='reset_passwords.php'">
                            <i class="fas fa-redo me-2"></i>Reset All Passwords
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="alert alert-warning mt-4">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Security Note:</strong> This page is for development/testing only.
            In production, remove this file and use strong, unique passwords for each account.
        </div>
    </div>

    <script>
        function copyCredentials(email, password) {
            const text = `Email: ${email}\nPassword: ${password}`;
            navigator.clipboard.writeText(text).then(() => {
                alert('Credentials copied to clipboard!');
            });
        }
    </script>
</body>

</html>