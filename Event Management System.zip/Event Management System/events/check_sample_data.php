<?php
require 'includes/db.php';

echo "Checking existing data...\n";

// Check if professionals already exist
$count = $pdo->query("SELECT COUNT(*) FROM professionals")->fetchColumn();

if ($count > 0) {
    echo "Found $count professionals already in database.\n";
    echo "Skipping professional creation.\n\n";

    // Get existing professional IDs
    $stmt = $pdo->query("SELECT id, email FROM professionals ORDER BY id");
    $existing_pros = $stmt->fetchAll();

    echo "Existing professionals:\n";
    foreach ($existing_pros as $pro) {
        echo "  ID: {$pro['id']} - {$pro['email']}\n";
    }
} else {
    echo "No professionals found. Run seed_data.php first.\n";
    exit;
}

// Check events
$event_count = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
echo "\nFound $event_count events in database.\n";

if ($event_count > 0) {
    echo "\n✅ Database already has sample data!\n";
    echo "\nYou can login with these credentials:\n";
    echo "Email: royal@eventhub.com | Password: password123\n";
    echo "Email: party@eventhub.com | Password: password123\n";
    echo "Email: livemusic@eventhub.com | Password: password123\n";
    echo "(and 7 more professionals...)\n";
} else {
    echo "\nNo events found. Something went wrong with seeding.\n";
}
?>