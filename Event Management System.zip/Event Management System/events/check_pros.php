<?php
require 'includes/db.php';
$pros = $pdo->query('SELECT name, profile_image FROM professionals')->fetchAll();
foreach ($pros as $p) {
    echo "Name: " . $p['name'] . " | Image: " . $p['profile_image'] . "\n";
}
?>