<?php
$host = 'localhost';
$dbname = 'eventhub';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected.\n";

    // Disable FK checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

    // DROP DATABASE
    echo "Dropping Database $dbname...\n";
    $pdo->exec("DROP DATABASE IF EXISTS $dbname");
    echo "Database Dropped.\n";

    // Re-create
    $pdo->exec("CREATE DATABASE $dbname");
    echo "Database Created.\n";
    $pdo->exec("USE $dbname");

    // Define queries individually
    $queries = [
        "CREATE TABLE users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(20),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "CREATE TABLE professionals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(20),
            category VARCHAR(50),
            bio TEXT,
            location VARCHAR(100),
            price_start DECIMAL(10,2),
            profile_image VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "CREATE TABLE categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL UNIQUE,
            image VARCHAR(255)
        )",
        "CREATE TABLE events (
            id INT AUTO_INCREMENT PRIMARY KEY,
            professional_id INT NOT NULL,
            title VARCHAR(150) NOT NULL,
            description TEXT,
            category_id INT,
            price DECIMAL(10,2),
            image VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",
        "CREATE TABLE bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            professional_id INT NOT NULL,
            event_id INT NOT NULL,
            booking_date DATE NOT NULL,
            booking_time TIME,
            status ENUM('pending', 'confirmed', 'completed', 'cancelled') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE,
            FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE
        )",
        "CREATE TABLE blocked_dates (
            id INT AUTO_INCREMENT PRIMARY KEY,
            professional_id INT NOT NULL,
            blocked_date DATE NOT NULL,
            reason VARCHAR(255),
            FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE
        )",
        "CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            sender_type ENUM('user', 'professional') NOT NULL,
            receiver_id INT NOT NULL,
            receiver_type ENUM('user', 'professional') NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "CREATE TABLE reviews (
            id INT AUTO_INCREMENT PRIMARY KEY,
            booking_id INT NOT NULL,
            user_id INT NOT NULL,
            professional_id INT NOT NULL,
            rating INT CHECK (rating >= 1 AND rating <= 5),
            comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (professional_id) REFERENCES professionals(id) ON DELETE CASCADE
        )",
        "CREATE TABLE notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT,
            professional_id INT,
            message VARCHAR(255),
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        "INSERT INTO categories (name) VALUES ('Function'), ('Party'), ('Concert'), ('Seminar'), ('Workspace'), ('Conference')"
    ];

    foreach ($queries as $sql) {
        $pdo->exec($sql);
        $display = substr(trim($sql), 0, 20);
        echo "Executed: $display...\n";
    }

    $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
    echo "DATABASE REPAIR COMPLETE (CLEAN SLATE).\n";

} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>