<?php
$path = './';
require 'includes/db.php';
require 'includes/functions.php';
require 'includes/image_helpers.php';
include 'includes/header.php';

// Fetch Categories
$stmt = $pdo->query("SELECT * FROM categories");
$categories = $stmt->fetchAll();

// Fetch Featured Events (Random for now)
$stmt = $pdo->query("SELECT e.*, p.name as professional_name, c.name as category_name 
                     FROM events e 
                     JOIN professionals p ON e.professional_id = p.id 
                     JOIN categories c ON e.category_id = c.id 
                     ORDER BY e.created_at DESC LIMIT 3");
$featured_events = $stmt->fetchAll();

// Fetch Top Creators (by booking count - placeholder logic)
$stmt = $pdo->query("SELECT * FROM professionals LIMIT 4");
$creators = $stmt->fetchAll();
?>

<!-- Hero Section -->
<section class="hero-section text-center position-relative">
    <div class="container">
        <h1 class="hero-title animate__animated animate__fadeInDown">Plan Your Dream Event</h1>
        <p class="lead mb-5 animate__animated animate__fadeInUp">Connect with top professionals for Weddings, Parties,
            and Corporate Events.</p>

        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="pages/events.php" method="GET" class="card card-body shadow-lg border-0 p-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <select name="category" class="form-select border-0 bg-light">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <input type="date" name="date" class="form-control border-0 bg-light">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary-gradient w-100">Search Events</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Categories -->
<section class="container mb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Browse Categories</h2>
        <a href="pages/events.php" class="text-decoration-none fw-bold text-primary">View All <i
                class="fas fa-arrow-right"></i></a>
    </div>

    <div class="row g-4">
        <?php foreach ($categories as $cat):
            $icon = 'fa-calendar-alt';
            if ($cat['name'] == 'Party')
                $icon = 'fa-glass-cheers';
            if ($cat['name'] == 'Concert')
                $icon = 'fa-music';
            if ($cat['name'] == 'Seminar')
                $icon = 'fa-chalkboard-teacher';
            if ($cat['name'] == 'Workspace')
                $icon = 'fa-laptop-house';
            if ($cat['name'] == 'Conference')
                $icon = 'fa-users';
            ?>
            <div class="col-6 col-md-4 col-lg-2">
                <div class="category-card h-100"
                    onclick="location.href='pages/events.php?category=<?php echo $cat['id']; ?>'">
                    <i class="fas <?php echo $icon; ?> category-icon"></i>
                    <h6 class="fw-bold mb-0"><?php echo $cat['name']; ?></h6>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Featured Events -->
<section class="bg-light py-5 mb-5">
    <div class="container">
        <h2 class="fw-bold text-center mb-5">Trending Events</h2>
        <div class="row g-4">
            <?php if (count($featured_events) > 0): ?>
                <?php foreach ($featured_events as $event): ?>
                    <div class="col-md-4">
                        <div class="card event-card h-100">
                            <img src="<?php echo getEventImage($event['image'], $event['category_name'], './'); ?>"
                                class="event-img" alt="<?php echo htmlspecialchars($event['title']); ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <span
                                        class="badge bg-primary bg-opacity-10 text-primary"><?php echo $event['category_name']; ?></span>
                                    <span class="fw-bold text-primary">₹<?php echo number_format($event['price'], 0); ?></span>
                                </div>
                                <h5 class="card-title fw-bold"><?php echo htmlspecialchars($event['title']); ?></h5>
                                <p class="text-muted small"><i class="fas fa-user-circle me-1"></i>
                                    <?php echo htmlspecialchars($event['professional_name']); ?></p>
                                <a href="pages/event_details.php?id=<?php echo $event['id']; ?>"
                                    class="btn btn-outline-primary w-100 mt-2 rounded-pill">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="text-center">
                    <p class="text-muted">No events found. Be the first to create one!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Top Creators -->
<section class="container mb-5">
    <h2 class="fw-bold mb-4">Top Creators</h2>
    <div class="row g-4">
        <?php if (count($creators) > 0): ?>
            <?php foreach ($creators as $creator): ?>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm text-center p-4 rounded-4">
                        <img src="<?php echo getProfessionalImage($creator['profile_image'], $creator['name'], './'); ?>"
                            class="rounded-circle mx-auto mb-3" width="80" height="80"
                            alt="<?php echo htmlspecialchars($creator['name']); ?>">
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($creator['name']); ?></h5>
                        <p class="text-muted small mb-2"><?php echo $creator['category'] ?? 'Professional'; ?></p>
                        <div class="text-warning small mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                        <a href="pages/professional_profile.php?id=<?php echo $creator['id']; ?>"
                            class="btn btn-sm btn-light rounded-pill">View Profile</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-muted">No professionals registered yet.</div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>