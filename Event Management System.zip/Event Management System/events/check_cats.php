<?php
require 'includes/db.php';
$cats = $pdo->query('SELECT name FROM categories')->fetchAll(PDO::FETCH_COLUMN);
print_r($cats);
?>