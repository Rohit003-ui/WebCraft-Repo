<?php
require '../includes/db.php';
require '../includes/functions.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    if ($_POST['action'] == 'send') {
        $msg = cleanInput($_POST['message']);
        $receiver_id = $_POST['receiver_id'];
        $receiver_type = $_POST['receiver_type'];

        $sender_id = 0;
        $sender_type = '';

        if (isset($_SESSION['user_id'])) {
            $sender_id = $_SESSION['user_id'];
            $sender_type = 'user';
        } elseif (isset($_SESSION['professional_id'])) {
            $sender_id = $_SESSION['professional_id'];
            $sender_type = 'professional';
        } else {
            die(json_encode(['status' => 'error', 'message' => 'Unauthorized']));
        }

        $stmt = $pdo->prepare("INSERT INTO messages (sender_id, sender_type, receiver_id, receiver_type, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$sender_id, $sender_type, $receiver_id, $receiver_type, $msg]);
        echo json_encode(['status' => 'success']);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['booking_id'])) {
    // We need to figure out the pair from booking_id or pass user_id/pro_id directly.
    // Ideally chat is between User and Pro.
    // If we only know booking_id, we can look up the pair.
    $booking_id = $_GET['booking_id'];

    // Fetch Booking to get participants
    $stmt = $pdo->prepare("SELECT user_id, professional_id FROM bookings WHERE id = ?");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch();

    if (!$booking)
        die(json_encode([]));

    $u_id = $booking['user_id'];
    $p_id = $booking['professional_id'];

    // Fetch messages between these two
    // Condition: (sender=u AND receiver=p) OR (sender=p AND receiver=u)
    $stmt = $pdo->prepare("
        SELECT * FROM messages 
        WHERE (sender_id = ? AND sender_type = 'user' AND receiver_id = ? AND receiver_type = 'professional')
           OR (sender_id = ? AND sender_type = 'professional' AND receiver_id = ? AND receiver_type = 'user')
        ORDER BY created_at ASC
    ");
    $stmt->execute([$u_id, $p_id, $p_id, $u_id]);
    $msgs = $stmt->fetchAll();

    // Return with "is_me" flag
    $output = [];
    $my_type = isset($_SESSION['user_id']) ? 'user' : 'professional';
    $my_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : $_SESSION['professional_id'];

    foreach ($msgs as $m) {
        $is_me = ($m['sender_type'] == $my_type && $m['sender_id'] == $my_id);
        $output[] = [
            'message' => $m['message'],
            'time' => date('h:i A', strtotime($m['created_at'])),
            'is_me' => $is_me
        ];
    }
    echo json_encode($output);
}
?>