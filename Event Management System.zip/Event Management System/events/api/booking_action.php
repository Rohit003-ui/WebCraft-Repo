<?php
require '../includes/db.php';
require '../includes/functions.php';

session_start();

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    die("Invalid Request");
}

$id = $_GET['id'];
$action = $_GET['action'];

if ($action == 'cancel_user' && isset($_SESSION['user_id'])) {
    // User cancelling
    $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'pending'");
    $stmt->execute([$id, $_SESSION['user_id']]);
    redirect('../user/my_bookings.php');

} elseif (isset($_SESSION['professional_id'])) {
    // Professional actions
    if ($action == 'confirm') {
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ? AND professional_id = ?");
        $stmt->execute([$id, $_SESSION['professional_id']]);
        // Also block the date? Maybe not automatically, depends on preference. 
        // If strict single-booking per date:
        // $b = ... fetch booking date ...
        // insert into blocked_dates ...
        // For now, we leave manual blocking or assume 'confirmed' bookings check 'confirmed' count (which we did in event_details).
    } elseif ($action == 'cancel') {
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND professional_id = ?");
        $stmt->execute([$id, $_SESSION['professional_id']]);
    } elseif ($action == 'complete') {
        $stmt = $pdo->prepare("UPDATE bookings SET status = 'completed' WHERE id = ? AND professional_id = ?");
        $stmt->execute([$id, $_SESSION['professional_id']]);
    }
    redirect('../professional/dashboard.php');
} else {
    die("Unauthorized");
}
?>