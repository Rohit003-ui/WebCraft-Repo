<?php
require '../includes/db.php';
require '../includes/functions.php';
session_start();
checkProfessionalLogin();

$pro_id = $_SESSION['professional_id'];
$date = $_POST['date'];
$action = $_POST['action'];
$reason = $_POST['reason'] ?? 'Manual Block';

if ($action == 'block') {
    // Check if not already blocked or booked
    // Ideally we check before insert
    $stmt = $pdo->prepare("INSERT IGNORE INTO blocked_dates (professional_id, blocked_date, reason) VALUES (?, ?, ?)");
    $stmt->execute([$pro_id, $date, $reason]);
} elseif ($action == 'unblock') {
    $stmt = $pdo->prepare("DELETE FROM blocked_dates WHERE professional_id = ? AND blocked_date = ?");
    $stmt->execute([$pro_id, $date]);
}

redirect('../professional/calendar.php');
?>